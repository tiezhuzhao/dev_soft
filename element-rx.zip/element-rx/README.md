# element-rx

> 瑞祥主案公共组件 布局结构

## 如何在项目使用element-rx

### 项目的webpack 配置

1. `@` 为项目资源主路径 `src`
2. 需要把项目下载到`src`目录下
3. 设置路径别名 `@rx`

```javascript
    alias: {
      'vue$': 'vue/dist/vue.esm.js',
      '@': resolve('src'),
      '@rx':resolve('src/element-rx'),
    }
```

### 如何引入

- 引入插件

```javascript
//main.js
import ElementRx from '@/element-rx'
Vue.use(ElementRx, {
    department: 'za', //部门标识
    loading: false // Whether or not to open loading true/false
})
```

- 路由配置 可在项目项目中查看模板列子

```javascript
//router.js 部分代码
import Vue from 'vue'
import Router from 'vue-router'
import ElementRx from '@rx/coreRouter'

Vue.use(Router)

export default new Router({
    mode: 'history',
    routes: [
        ...ElementRx
    ]
})
```

- vuex 配置 适配公共功能

```javascript
//store.js
import Vue from 'vue'
import Vuex from 'vuex'
import ElementRx from '@rx/coreStore'

Vue.use(Vuex)

// 创建 store 实例
export default new Vuex.Store({
    strict: process.env.NODE_ENV !== 'production',
    modules: {
        ElementRx
    }
})
```

- 配置组件渲染内容

```html
<template>
<rx-app>
    <rx-header></rx-header>
    <rx-aside></rx-aside>
    <rx-main>
        <router-view id="components"></router-view>
    </rx-main>
</rx-app>
</template>
<script>
export default {
    name: 'App'
}
</script>
<style>
</style>

```
