/* style scss */
import './src/styles/index.scss'

/* function functions */
import functions from './src/functions/index'

/* directive directives */
import directives from './src/directives'

/* filter filters */
import filters from './src/filters'

/* component components */
import components from './packages'

/* utils all in */
import utils from './utils'

/* Vue.use() */
const install = function (Vue, opts = {}) {
    components.map(component => {
        Vue.component(component.name, component)
    })
    filters.map(filter => {
        Vue.filter(filter.name, filter.value)
    })
    directives.map(directive => {
        Vue.directive(directive.name, directive)
    })
    Vue.prototype.$ELEMENTRX = {
        department: opts.department || '',
        loading: opts.loading || false
    }
    Vue.prototype.$utils = utils
    Vue.prototype.$functions = functions
}

/* istanbul ignore if */
if (typeof window !== 'undefined' && window.Vue) {
    install(window.Vue)
}

// element-ui  babel-plugin-component
const exportComponents = {
    install,
    functions,
    directives,
    filters,
    components,
    utils
}

export default exportComponents
