# 上传示例

```html
<link rel="stylesheet" href="https://zstatic.rxjy.com/element-rx/static/packages-browser/upload/index.css">
<!-- 上传框样式布局 -->
<div id="uploadImg" class="fl uiImgUpload uiImgUpload-gblock mr10" style="width: 120px;height: 140px;">
    <a href="javascript:" >
        <span class="file"></span>
        <em class="bgIcon file-ico"></em>
    </a>
</div>
<!-- 展示样式布局 -->
<div class="look_imgHover fl relative ml20" style="width:144px;height:184px;">
    <img src="http://img0.wenes.cn/Upload/Project/Image/2018/07/06/thumbnail/17571276269085.jpg">
    <div class="upload_finish_div">
        <div class="upload_finish_bg"></div>
        <div class="upload_finish_link">
            <div class="dis-il-block">
                <a href="javascript:" class="ImgBtn oneImgLarge enlarge_link" data-src="http://img0.wenes.cn/Upload/Project/Image/2018/07/06/thumbnail/17571276269085.jpg"></a>
                <a href="javascript:" class="ImgBtn delect_link"></a>
            </div>
        </div>
    </div>
</div>
<script src="https://zstatic.rxjy.com/element-rx/static/components/plupload/js/plupload.full.min.js"></script>
<script src="https://zstatic.rxjy.com/element-rx/packages-browser/upload/index.js"></script>
<script>
// 注册全局上传类
var pluploadza = new PluploadRx({
    department: 'za',
    env: 'production'
})
// 创建一个可上传的容器
pluploadza.uploader({
    id: 'uploadImg',
    class: 1,
    mime: 1,
    multi: true,
    success: function (results) {
        console.log(results)
    },
    error: function (error) {
        console.log(error)
    }
})
</script>
```
