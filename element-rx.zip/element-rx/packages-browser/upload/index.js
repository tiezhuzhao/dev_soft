/**
 * 浏览器版的上传，和vue的同配置同步。
 * @param { Object } config 全局初始化配置
 */
// eslint-disable-next-line
var PluploadRx = function (config) {
    /**
     * loading 样式元素, 模拟 element-ui 的上传进度
     */
    this.loadingEle = '<div class="loadingPage"><div class="loadingPage-spinner"><svg viewBox="25 25 50 50"class="circular"><circle cx="50"cy="50"r="20"fill="none"class="path"></circle></svg><p class="loadingPage-text"></p></div></div>'
    /**
     * element 全局变量
     */
    this.$ELEMENTRX = {
        department: config.department,
        loading: true
    }
    /**
     * 环境变量设置
     */
    var process = {
        env: {
            NODE_ENV: config.env
        }
    }
    /**
     * 目录配置 只配置一级目录  二级通用
     */
    var configfile = {
        // 二级目录配置通用
        secondLevel: {
            1: '/Images', // 图片
            2: '/Zips', // 压缩包
            3: '/VideoAudio', // 音频视频
            4: '/Docs' // 文档文本资料一类
        },
        // 具体部门
        sw: {
            production: '',
            development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
            options: {

            }
        },
        za: {
            production: 'https://oss.rxjy.com/wenes01/getOSSToken',
            development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
            options: {
                1: 'ProjectBusiness', // 业务
                2: 'DesignInstitute', // 设计院
                3: 'ProjectBusiness', // 业务/人事/财务/其他工具类
                4: 'FurnitureWeakCurrent' // 家具弱电
            }
        },
        gc: {
            production: '',
            development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
            options: {

            }
        },
        ds: {
            production: '',
            development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
            options: {

            }
        },
        pt: {
            production: '',
            development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
            options: {

            }
        },
        tz: {
            production: '',
            development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
            options: {

            }
        },
        kg: {
            production: '',
            development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
            options: {

            }
        }
    }
    /**
     * 上传配置 初始化参数类的
     */
    this.init = {}
    /**
     * 定义参数
     */
    // 部门信息
    this.department = {}
    // 上传实例
    this.PluploadInstance = null
    // 是否开启loading
    this.loading = false
    // 上传个数
    this.loadingLength = 0
    // 当前上传索引
    this.loadingCur = 0
    // 每个的上传进度
    this.loadingProcess = ''
    // 图片接口地址
    this.serverUrl = ''
    // 上传分类限制
    this.mime = []
    // Token信息
    this.Token = {}
    // 计算后的图片路径
    this.imageUrl = ''
    /**
     * 初始化上传实例
     */
    this.uploader = function (uploader) {
        // 初始覆盖参数
        this.init = uploader
        // 添加 loading 元素
        $('#' + this.init.id).append(this.loadingEle)
        // 获取部门信息
        try {
            let department = this.$ELEMENTRX.department
            if (!department) {
                // eslint-disable-next-line
                alert('部门ID未设置，请紧急联系前端解决')
                return false
            }
            this.department = configfile[department]
            this.department.secondLevel = configfile.secondLevel
        } catch (e) {
            // eslint-disable-next-line
            alert('部门ID未设置，请紧急联系前端解决')
            return false
        }

        // 判断上传环境
        if (process.env.NODE_ENV === 'development') {
            this.serverUrl = this.department.development
        } else {
            this.serverUrl = this.department.production
        }

        // 条件判断
        // - 必须要初始值
        if (!this.init) {
            alert('无初始对象')
            return false
        }
        // - 必须有分类
        if (!this.department.options[this.init.class]) {
            alert('无此分类 或 缺少class')
            return false
        }
        // - 必须有类型
        if (!this.department.secondLevel[this.init.mime]) {
            alert('无此图片类型 或 缺少mime')
            return false
        }
        // - 限制上传类型
        if (this.init.mime === 1) {
            this.mime.push({title: 'Image files', extensions: 'jpg,gif,png,bmp,jpeg'})
        } else if (this.init.mime === 2) {
            this.mime.push({title: 'Zip files', extensions: 'zip,rar'})
        } else {
            this.mime = []
        }

        // 初始化 over
        this.initUploader()
    }
    // 初始化 实例
    this.initUploader = function () {
        this.PluploadInstance && this.PluploadInstance.destroy()
        let _this = this
        // eslint-disable-next-line
        this.PluploadInstance = new plupload.Uploader({
            runtimes: 'html5,flash,silverlight,html4',
            browse_button: _this.init.id,
            multi_selection: _this.init.multi || false,
            // container: _this.$el,
            // flash_swf_url: 'lib/plupload-2.1.2/js/Moxie.swf',
            // silverlight_xap_url: 'lib/plupload-2.1.2/js/Moxie.xap',
            url: 'http://oss.aliyuncs.com',
            filters: {
                mime_types: _this.mime, // 上传类型判断
                max_file_size: '100mb', // 最大只能上传30mb的文件
                prevent_duplicates: false // 不允许选取重复文件
            },
            init: {
                // 当init 初始后执行
                PostInit () {
                    // console.log('PostInit-------', '初始化完成')
                },
                // 当文件添加到上传队列后触发监听函数参数(此列子是显示了名字)
                FilesAdded (up, files) {
                    // 初始上传进度
                    // _this.loading = true
                    $('.loadingPage').show()
                    _this.loadingLength = files.length
                    _this.loadingCur = 0

                    _this.setuploadParam(up, '', false)

                    // console.log('FilesAdded------', files)
                },
                // 当队列中的某一个文件正要开始上传前触发监听函数参数
                BeforeUpload (up, file) {
                    // 当前上传的索引
                    _this.loadingCur = _this.loadingCur + 1

                    _this.setuploadParam(up, file.name, true)

                    // console.log('BeforeUpload----------', file)
                },
                // 上传进度
                UploadProgress (up, file) {
                    _this.loadingProcess = `${_this.loadingCur}/${_this.loadingLength}  ${file.percent}%`
                    $('.loadingPage .loadingPage-text').text(_this.loadingProcess)
                    // console.log('UploadProgress -------- ', file)
                },
                // 上传文件后
                FileUploaded (up, file, info) {
                    // 如果是最后一个上传完毕
                    if (_this.loadingLength === _this.loadingCur) {
                        // _this.loading = false
                        $('.loadingPage').hide()
                    }
                    if (info.status === 200) {
                        let successUrl = _this.Token['uploadUrl'] + '/' + _this.imageUrl
                        let successObj = {
                            src: successUrl,
                            init: _this.init
                        }
                        if (_this.data) {
                            successObj.data = _this.data
                        }
                        // 返回上传成功值
                        // _this.$emit('success', successObj)
                        _this.init.success(successObj)
                        // console.log('FileUploaded', successUrl)
                    } else {
                        alert(info.response)
                        // _this.$emit('error', info.response)
                        if (typeof this.init.error === 'function') {
                            _this.init.error(info.response)
                        }
                    }
                    // console.log('FileUploaded ----------- ', file, info)
                },
                // 错误回调
                Error (up, err) {
                    // _this.loading = false
                    $('.loadingPage').hide()
                    // _this.$emit('error', err.response)
                    if (typeof this.init.error === 'function') {
                        _this.init.error(err.response)
                    }
                    if (err.code === -600) {
                        alert('选择的文件太大了')
                    } else if (err.code === -601) {
                        alert('选择的文件后缀不对')
                    } else if (err.code === -602) {
                        alert('这个文件已经上传过一遍了')
                    } else {
                        alert(err.response)
                    }
                }
            }
        })
        this.PluploadInstance.init()
    }
    // 请求 Token
    this.sendRequest = function () {
        var xmlhttp = null
        if (window.XMLHttpRequest) {
            xmlhttp = new XMLHttpRequest()
        } else if (window.ActiveXObject) {
            /* eslint-disable-next-line */
            xmlhttp = new ActiveXObject('Microsoft.XMLHTTP')
        }
        if (xmlhttp != null) {
            xmlhttp.open('GET', this.serverUrl, false)
            xmlhttp.send(null)
            return xmlhttp.responseText
        } else {
            alert('Your browser does not support XMLHTTP.')
        }
    }
    // 设置上传参数
    this.setuploadParam = function (up, filename, ret) {
        if (ret === false) {
            ret = this.getSignature()
        }
        if (filename !== '') {
            this.calculateObjectName(filename)
        }
        let multipartParams = {
            'key': this.imageUrl,
            'policy': this.Token['policy'],
            'OSSAccessKeyId': this.Token['accessKey'],
            'success_action_status': '200', // 让服务端返回200,不然，默认会返回204
            // 'callback': callbackbody,
            'signature': this.Token['signature']
        }
        // console.log('multipartParams-----------', multipartParams)
        up.setOption({
            'url': this.Token['uploadUrl'],
            'multipart_params': multipartParams
        })
        up.start()
    }
    // 设置 Token
    this.getSignature = function () {
        // 可以判断当前expire是否超过了当前时间,如果超过了当前时间,就重新取一下.300s 做为缓冲
        let body = this.sendRequest()
        this.Token = JSON.parse(body)
        // now = timestamp = Date.parse(new Date()) / 1000
        // if (expire < now + 300) {
        //     let body = this.sendRequest()
        //     console.log(JSON.parse(body))
        //     var obj = eval('(' + body + ')')
        //     host = obj['uploadUrl']
        //     policyBase64 = obj['policy']
        //     accessid = obj['accessKey']
        //     signature = obj['signature']
        //     uploadUrl = obj['uploadUrl']
        //     // expire = parseInt(obj['expire'])
        //     // callbackbody = obj['callback']
        //     // key = obj['dir']
        //     return true
        // }
        // return false
    }
    // 获取随机字符串
    this.randomString = function (len) {
        len = len || 32
        var chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz0123456789'
        var maxPos = chars.length
        var pwd = ''
        for (let i = 0; i < len; i++) {
            pwd += chars.charAt(Math.floor(Math.random() * maxPos))
        }
        let timestamp = Date.parse(new Date()) / 1000
        return timestamp + pwd
    }
    // 截取后缀名
    this.getSuffix = function (filename) {
        let pos = filename.lastIndexOf('.')
        let suffix = ''
        if (pos !== -1) {
            suffix = filename.substring(pos)
        }
        return suffix
    }
    // 获取文件目录
    this.getUploadFolder = function (suffix) {
        let folder = ''
        // 判断一级目录
        folder += this.department.options[this.init.class]
        // 判断二级目录
        folder += this.department.secondLevel[this.init.mime]
        return folder
    }
    // 获取文件名
    this.calculateObjectName = function (filename) {
        // 获取目录名
        let folder = this.getUploadFolder()
        // 获取随机名称
        let randomName = this.randomString(24)
        // 获取后缀名
        let suffix = this.getSuffix(filename)
        // 生成路径
        this.imageUrl = `${folder}/${randomName}${suffix}`
    }
}
