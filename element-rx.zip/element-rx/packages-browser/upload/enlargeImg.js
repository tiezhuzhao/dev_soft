﻿/* eslint-disable */
// 单张图片放大
var oneImgLarge = function () {
    $('.oneImgLarge').each(function (i) {
        $(this).off('click').on('click', function () {
            var thisclick = this
            var thisId = 'preview_' + i
            var curId = 'CurImg_' + i
            // 图片放大
            rxued.images.enSingleLarge(thisclick, thisId, curId)

            // 点击旋转按钮
            rxued.images.rotateBtnClick(thisId, curId)
            // 关闭图片放大弹出层
            rxued.images.closeImgAlert(thisId)
            // 1:1
            rxued.images.oneToone(thisId, curId)
        })
    })
}
// oneImgLarge()
// 一组图片放大不需要加自定义属性data-msg
var groupEnlarge = function () {
    $('.groupEnlarge').each(function (i) {
        $(this).click(function () {
            var thisclick = this
            var thisId = 'preview_' + i
            var curId = 'CurImg_' + i
            // 图片放大
            rxued.images.enGroupLarge(thisclick, thisId, curId)

            // 点击旋转按钮
            rxued.images.rotateBtnClick(thisId, curId)
            // 关闭图片放大弹出层
            rxued.images.closeImgAlert(thisId)
            // 1:1
            rxued.images.oneToone(thisId, curId)
        })
    })
}
// groupEnlarge()

// 多张图片放大
var morePicLarge = function () {
    $('.morePicLarge').each(function () {
        var _msg, _label
        $(this).find('.moreImgLarge').each(function (i) {
            $(this).click(function () {
                _msg = $(this).attr('data-msg')
                _label = $(this).prop('tagName')
                var thisIndex = i
                var thisclick = this
                var thisId = 'preview_' + i
                var curId = 'CurImg_' + i
                // 图片放大
                rxued.images.morePicLarge(thisclick, thisId, curId, thisIndex, _msg, _label)
                // more表示data-msg的值， img表示要放大的图片元素

                // 点击旋转按钮
                rxued.images.rotateBtnClick(thisId, curId)
                // 关闭图片放大弹出层
                rxued.images.closeImgAlert(thisId)
                // 1:1
                rxued.images.oneToone(thisId, curId)
            })
        })
    })
}
