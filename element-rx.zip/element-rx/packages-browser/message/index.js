/**
 * 全局页面通信方法
 */
/**
 * 父级接收方法, 如果收到的是隐藏标题的
 * @param { Boolean } value
 */
const listenerChildrenMessageTitle = function (value) {
    if (value.title) {
        let componentsTitle = document.querySelectorAll('.components-title')
        for (let index = 0; index < componentsTitle.length; index++) {
            const item = componentsTitle[index]
            item.style.display = 'block'
        }
    } else {
        let time = setTimeout(() => {
            let componentsTitle = document.querySelectorAll('.components-title')
            for (let index = 0; index < componentsTitle.length; index++) {
                const item = componentsTitle[index]
                item.style.display = 'none'
            }
            clearTimeout(time)
        }, value.time || 222)
    }
}

/**
 * 监听通信传值
 */
window.addEventListener('message', function (value) {
    if (value.data.title === true || value.data.title === false) {
        listenerChildrenMessageTitle(value.data)
    } else {

    }
})

/**
 * 子页面调用方法
 * @param { Object } data
 */
window.postParentMessage = function (data = {}) {
    try {
        window.parent.postMessage(data)
    } catch (e) {
        // eslint-disable-next-line
        alert('通信调用错误，请检查嵌套关系')
    }
}
