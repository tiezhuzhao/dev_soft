import Index from '../components/components/Index/Resources/Router/index'
import Layout from '../components/components/Layout/Resources/Router/index'

export default [
    {
        path: '/',
        redirect: '/ElementRx'
    },
    { // 测试入口
        path: '/ElementRx',
        redirect: '/ElementRx/Layout',
        component: () => import('../components/components/Entry.vue'),
        children: [
            { // 模板-功能
                path: 'Index',
                component: () => import('../components/components/Index/Index.vue'),
                children: Index
            },
            { // 模板-布局
                path: 'Layout',
                component: () => import('../components/components/Layout/Index.vue'),
                children: Layout
            }
        ]
    },
    {
        path: '404',
        component: require('@rx/coreRouter/404.vue').default
    },
    {
        path: '*',
        component: require('@rx/coreRouter/redirect.vue').default
    }
]
