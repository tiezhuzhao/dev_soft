<template>
 <div class="page">
    <img src="https://zstatic.rxjy.com/element-rx/static/images/nofind_img2.png" alt="">
 </div>
</template>
<script>
export default {
    name: '',
    components: {

    },
    data () {
        return {

        }
    }
}
</script>
<style lang="scss" scoped>
.page  {
    text-align: center;
    img {
        width: 50%;
        margin:  50px auto;
    }
}
</style>
