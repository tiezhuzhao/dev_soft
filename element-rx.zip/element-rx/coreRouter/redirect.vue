<template>
    <page404></page404>
</template>
<script>
import page404 from './404.vue'
export default {
    components: {
        page404
    },
    data () {
        return {

        }
    },
    created () {
        let hash = this.$route.path
        this.$router.push(hash.slice(hash.indexOf('/'), hash.replace('/', 'a').indexOf('/') + 1 || hash.length))
    }
}
</script>
<style>
</style>
