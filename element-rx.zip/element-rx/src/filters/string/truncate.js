/**
 * 当文字超过一定长度的时候截取文字 number 截取文字的长度
 * @param { Number } length 截取的字符长度 || default length
 * @example 'lorem ipsum dolor' => 'lorem ipsum dol...'
 */
const truncate = (value, length = 10) => {
    if (!value || typeof value !== 'string') return ''
    if (value.length <= length) return value
    return value.substring(0, length) + '...'
}

export default {
    name: 'truncate',
    value: truncate
}
