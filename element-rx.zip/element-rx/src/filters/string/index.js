import truncate from './truncate'
import slice from './slice'

export default [
    truncate,
    slice
]
