/**
 * slice 解决非字符串报错的问题
 * @param { String } strs 要截取的字符串
 * @param { Number } start 开始索引
 * @param { Number } end 结束索引
 * @example 'lorem ipsum dolor' => 'lorem ipsum dol'
 */
const slice = (strs, start = 0, end = 0) => {
    if (typeof strs !== 'string') {
        return ''
    } else {
        end = end || strs.length
        return strs.slice(start, end)
    }
}

export default {
    name: 'slice',
    value: slice
}
