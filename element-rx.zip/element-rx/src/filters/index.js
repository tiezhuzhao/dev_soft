import number from './number'
import string from './string'
import others from './others'

export default [
    ...number,
    ...string,
    ...others
]
