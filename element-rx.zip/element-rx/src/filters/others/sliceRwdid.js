/**
 * 截取单号，截取规则 11-32323-3232 截取第几个 - 到第几个 - 之间的, 默认截取到末尾
 * @param { String } strs 要截取的字符串
 * @param { Number } start 开始索引
 * @param { Number } end 结束索引
 * @example '11-34298' => '34298'
 */
const sliceRwdid = (strs, start = 1, end = null) => {
    if (typeof strs !== 'string') {
        return ''
    } else {
        let ary = strs.split('-')
        let newAry = []
        for (let i = start; i < (end || ary.length); i++) {
            newAry.push(ary[i])
        }
        let newString = newAry.join('-')
        return newString
    }
}

export default {
    name: 'sliceRwdid',
    value: sliceRwdid
}
