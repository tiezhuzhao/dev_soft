/**
 * 根据图片路径获取缩略图
 * @param { String } url 图片元素路径
 * @param { Number } w 缩略图宽
 * @param { Number } h 缩略图高
 * @example 16062380347896.jpg => 16062380347896.jpg?x-oss-process=image/resize,m_fill,h_100,w_100,limit_0
 */
const smallImg = (url, w, h) => {
    let simgurl = ''
    if (!url) return simgurl
    // 如果是老的图片链接
    if (url.includes('http://img0.wenes.cn') || url.includes('http://zatp.wenes.cs')) {
        let ImgName = url.substring(url.lastIndexOf('/'), url.length)
        simgurl = url.replace(ImgName, '/thumbnail' + ImgName)
    } else { // oss 图片链接
        simgurl = `${url}?x-oss-process=image/resize,m_fill,h_${Number.parseFloat(h)},w_${Number.parseFloat(w)},limit_0`
    }
    return simgurl
}

export default {
    name: 'smallImg',
    value: smallImg
}
