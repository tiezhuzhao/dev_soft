/**
 * 类型返回中文
 * @param { Number } types 类型ID
 * @example 1 => '办公'
 */
const panyType = (types) => {
    let type = Number(types)
    if (type === 1) {
        return '办公'
    } else if (type === 2) {
        return '餐饮'
    } else if (type === 3) {
        return '商业'
    } else if (type === 4) {
        return '酒店'
    } else if (type === 5) {
        return '其他'
    } else if (type === 6) {
        return '教育'
    } else if (type === 7) {
        return '会所'
    } else {
        return '-'
    }
}

export default {
    name: 'panyType',
    value: panyType
}
