/**
 * 阶段返回中文
 * @param { Number } stages 阶段ID
 * @example 1 => '接单'
 */
const stage = (stages) => {
    let stage = Number(stages)
    if (!stage && stage !== 0) {
        return stages
    }
    if (stage === 0) {
        return '量房'
    } else if (stage === 1) {
        return '接单'
    } else if (stage === 2) {
        return '方案'
    } else if (stage === 6) {
        return '预算'
    } else if (stage === 8) {
        return '合同'
    } else if (stage === 10) {
        return '未签'
    } else if (stage === 11) {
        return '审计'
    } else if (stage === 12) {
        return '准备'
    } else if (stage === 13) {
        return '在施'
    } else if (stage === 14) {
        return '竣工'
    } else if (stage === 15) {
        return '完工'
    } else if (stage === 16) {
        return '历史'
    } else {
        return '-'
    }
}

export default {
    name: 'stage',
    value: stage
}
