import smallImg from './smallImg'
import panyType from './panyType'
import stage from './stage'
import sliceRwdid from './sliceRwdid'

export default [
    smallImg,
    panyType,
    stage,
    sliceRwdid
]
