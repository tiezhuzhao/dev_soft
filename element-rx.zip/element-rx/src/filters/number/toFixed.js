/**
 * 保留小数点 做一点判断 防止报错
 * @param { Number } length 保留的位数 || default length
 * @example 11.123 => 11.22
 */
const toFixed = (umber, leng = 2) => {
    let number = Number(umber)
    if (!number) {
        return 0
    } else {
        return number.toFixed(leng)
    }
}

export default {
    name: 'toFixed',
    value: toFixed
}
