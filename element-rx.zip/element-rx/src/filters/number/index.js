import toFixed from './toFixed'
import capitalizeAmount from './capitalizeAmount'

export default [
    toFixed,
    capitalizeAmount
]
