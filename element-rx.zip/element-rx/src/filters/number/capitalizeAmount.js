import utils from '../../../utils'

/**
 * 将数字转换为大写金额
 * @param { Number } money
 * @example 13 => 壹拾叁圆贰角
 */
const capitalizeAmount = (money) => {
    return utils.capitalizeAmount(money)
}

export default {
    name: 'capitalizeAmount',
    value: capitalizeAmount
}
