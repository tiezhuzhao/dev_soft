// 非特殊字符
const noSpecial = (el, binding) => {
    el.addEventListener('keyup', () => {
        // eslint-disable-next-line
        let noSpecialReg = /[`~!@#$%^&*()_\-+=<>?:"{}|,.\/;'\\[\]·~！@#￥%&*（）\-+={}|《》？：“”【】、；‘’，。、]/img
        el.value = el.value.replace(noSpecialReg, '')
        el.dispatchEvent(new Event('input'))
    })
}

// 钱的合法字符 , 能输入数字，一个小数点(小数点不能是首位)，小数点后两位
const money = (el, binding) => {
    el.addEventListener('keyup', () => {
        el.value = el.value.replace(/[^\d.]/g, '').replace(/^\./g, '').replace(/\.{2,}/g, '.').replace('.', '$#$').replace(/\./g, '').replace('$#$', '.').replace(/^(\\-)*(\d+)\.(\d\d).*$/, '$1$2.$3')
        el.dispatchEvent(new Event('input'))
    }, false)
}

// 只能输入数字
const number = (el, binding) => {
    el.addEventListener('keyup', () => {
        el.value = el.value.replace(/[^\d]/g, '')
        el.dispatchEvent(new Event('input'))
    }, false)
}

export default {
    name: 'types',
    bind (el, binding) {
        let modifiers = binding.modifiers
        if (modifiers.noSpecial) noSpecial(el)
        if (modifiers.money) money(el)
        if (modifiers.number) number(el)
    }
}
