import utils from '../../utils'

/**
 * 计算内容的高度 以显示滚动条
 * 滚动高度条 窗口高度 - 元素距离body的偏移量 - binding.value || 0
 * v-scrollHeight[, ={Number}]
 */
const win = () => {
    return document.documentElement.clientHeight || document.body.clientHeight
}

const getoffset = (el) => {
    let offsetTop = utils.offset(el).top
    try {
        if (el.parentNode.parentNode.id === 'j-tc-center-content' && offsetTop === 0) {
            if (utils.$('#main_header')) {
                offsetTop = 166
            } else {
                offsetTop = 126
            }
        }
    } catch (e) {

    }

    return offsetTop
}

const getsubtract = (el, binding) => {
    let subtract = binding.value || 0
    return subtract
}

const setStyle = (el, h) => {
    utils.setCss(el, 'height', h)
    utils.setCss(el, 'overflowY', 'auto')
    utils.setCss(el, 'width', '100%')
    utils.addClass(el, 'thinScroll')
}

export default {
    name: 'scrollHeight',
    bind (el, binding) {
        setTimeout(() => {
            setStyle(el, win() - getoffset(el) - getsubtract(el, binding))
        })
        // 监听窗口变化
        window.addEventListener('resize', () => {
            setStyle(el, win() - getoffset(el) - getsubtract(el, binding))
        }, false)
    }
}
