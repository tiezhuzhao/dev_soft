/**
 * 使用事件捕获 封装 layer tips 效果
 * data-title 提示文字
 * data-title-length 限制多少字显示提示
 * data-title-color 提示背景色
 */
document.documentElement.addEventListener('mouseenter', event => {
    let ev = event || window.event
    let target = ev.target || event.srcElement
    let tips = target.getAttribute('data-title')
    let length = target.getAttribute('data-title-length')
    let color = target.getAttribute('data-title-color')
    // 限制条件
    if ((!tips) || (!Number.isNaN(Number(length)) && tips.length <= length)) return false
    layer.tips(tips, target, {
        tips: [1, color || '#3595CC'],
        time: 0
    })
    let closeTips = function (event) {
        event.stopPropagation()
        layer.closeAll('tips')
        // 监听成功之后 移除事件
        target.removeEventListener('mouseleave', closeTips, false)
    }
    target.addEventListener('mouseleave', closeTips, false)
}, true)
