import './window/index'

import prototype from './prototype/index'

export default {
    ...prototype
}
