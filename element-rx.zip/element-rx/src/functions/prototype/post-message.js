/**
 * 子页面调用方法
 * @param { Object } data
 */
const postParentMessage = function (data) {
    window.postParentMessage(data)
}

export default postParentMessage
