import postParentMessage from './post-message'

export default {
    postParentMessage
}
