/**
 * 测试专用方法 是否是嵌套的别人的页面的标识
 */
window.BorderCtr = function () {
    $('.lineDistance, .borderCtr0').toggleClass('hide')
    if ($('.lineDistance, .borderCtr0').length === 0) {
        layer.alert('未引用其他产品内容')
    }
    return '~~测试专属调用~~'
}
