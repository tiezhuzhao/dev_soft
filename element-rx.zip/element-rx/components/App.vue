<template>
    <router-view id="app">
        <!-- 主入口容器 -->
    </router-view>
</template>
<script>
export default {
    name: 'App'
}
</script>
