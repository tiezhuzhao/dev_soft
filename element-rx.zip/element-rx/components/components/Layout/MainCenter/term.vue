<template>
    <div class="">
        <div class="pr10">
            <div class="analyItem">
                <p class="analyItemTit tx-center">状态</p>
                <div class="analyItemCon">
                    <span class="cGreen">2A客户</span>
                </div>
            </div>
        </div>
        <div class="thinScroll pr10" v-scrollHeight="10">
            <div class="analyItem">
                <p class="analyItemTit tx-center">企业</p>
                <div class="analyItemCon">
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">类型</span>
                        <span>餐饮</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">性质</span>
                        <span>私企</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">规模</span>
                        <span>30-50人</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">全称</span>
                        <span>欧若拉牛排</span>
                    </p>
                    <span><span class="circlemark circlemark-lightRed">B</span></span>
                    <div class="fixedTrangle"><span href="javascript:" class="fixedtips"></span>
                        <div class="fixedtipscon pt10 pb10"> <i></i>
                            <div>
                                <div>
                                    <p>X:实际分数</p>
                                    <p>满分:5分</p>
                                    <p>A:5≤X≤10</p>
                                    <p>B:2≤X≤4</p>
                                    <p>C:0≤X≤1</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="analyItem">
                <p class="analyItemTit tx-center">客户</p>
                <div class="analyItemCon">
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">职务</span>
                        <span>老板</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">性别</span>
                        <span>女</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">年龄</span>
                        <span>30岁-50岁</span>
                    </p>
                    <span><span class="circlemark circlemark-lightRed">C</span></span>
                    <div class="fixedTrangle"><span href="javascript:" class="fixedtips"></span>
                        <div class="fixedtipscon pt10 pb10"> <i></i>
                            <div>
                                <div>
                                    <p>X:实际分数</p>
                                    <p>满分:5分</p>
                                    <p>A:5≤X≤10</p>
                                    <p>B:2≤X≤4</p>
                                    <p>C:0≤X≤1</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="analyItem">
                <p class="analyItemTit tx-center">房源</p>
                <div class="analyItemCon">
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">现状</span>
                        <span>清水房</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">房源</span>
                        <span>已定</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">面积</span>
                        <span>262.00</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">成交</span>
                        <span>租</span>
                    </p>
                    <p class="col-md-8">
                        <span class="pr8 cLightGray">地址</span>
                        <span>合肥-滨湖区-滨湖区其他-万达茂-A-3</span>
                    </p>
                    <span><span class="circlemark circlemark-lightRed">A</span></span>
                    <div class="fixedTrangle"><span href="javascript:" class="fixedtips"></span>
                        <div class="fixedtipscon pt10 pb10"> <i></i>
                            <div>
                                <div>
                                    <p>X:实际分数</p>
                                    <p>满分:5分</p>
                                    <p>A:5≤X≤10</p>
                                    <p>B:2≤X≤4</p>
                                    <p>C:0≤X≤1</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="analyItem">
                <p class="analyItemTit tx-center">装修</p>
                <div class="analyItemCon">
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">属性</span>
                        <span>正常单</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">目的</span>
                        <span>扩大经营</span>
                    </p>
                    <p class="col-md-4">
                        <span class="pr8 cLightGray">开工</span>
                        <span>2018-09-04</span>
                    </p>
                    <span><span class="circlemark circlemark-lightRed">A</span></span>
                    <div class="fixedTrangle"><span href="javascript:" class="fixedtips"></span>
                        <div class="fixedtipscon pt10 pb10"> <i></i>
                            <div>
                                <div>
                                    <p>X:实际分数</p>
                                    <p>满分:5分</p>
                                    <p>A:5≤X≤10</p>
                                    <p>B:2≤X≤4</p>
                                    <p>C:0≤X≤1</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data () {
        return {

        }
    }
}

</script>
