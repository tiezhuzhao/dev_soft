// 测试用例不要使用
export const SET_DEMO = `SET_DEMO`
