<template>
    <iframe class="pr10" width="100%" height="100%" src="/ElementRx/Index?cutting=1" frameborder="0"></iframe>
</template>
<script>
export default {
    data () {
        return {

        }
    }
}
</script>
