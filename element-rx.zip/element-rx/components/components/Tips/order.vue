<template>
<div class="layerRtb layerRtb-threecolumn layerRtb-right" style="background:transparent">
    <div class="tips-mark"></div>
    <div class="messageBox mt10">
        <strong class="tips-right--close" @click="setHeaderTip()">×</strong>
        <div class="layerRtb-scroll thinScroll" v-scrollHeight = "10">
            <div class="analyItem">
                <p class="analyItemTit tx-center">预留</p>
                <div class="analyItemCon">
                    <p class="col-md-4">
                        <span class="cLightGray pr8">名称</span>
                        <span>预留名称</span>
                    </p>
                </div>
            </div>
            <div class="analyItem">
                <p class="analyItemTit tx-center">预留</p>
                <div class="analyItemCon">
                    <p class="col-md-4">
                        <span class="cLightGray pr8">名称</span>
                        <span>预留名称</span>
                    </p>
                </div>
            </div>
            <div class="analyItem">
                <p class="analyItemTit tx-center">预留</p>
                <div class="analyItemCon">
                    <p class="col-md-4">
                        <span class="cLightGray pr8">名称</span>
                        <span>预留名称</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
<script>
import { mapMutations } from 'vuex'
export default {
    data () {
        return {

        }
    },
    created () {

    },
    methods: {
        ...mapMutations({
            setHeaderTip: 'SET_HEADER_TIP'
        })
    }
}
</script>
<style scoped>
.messageBox {
    width: calc(100% - 740px);
    margin-left: 740px;
    z-index: 10;
    position: relative;
}
</style>
