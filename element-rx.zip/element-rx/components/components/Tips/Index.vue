<template>
<div class="clearfix">
    <transition  class="animated faster" enter-active-class="animated faster slideInRight" leave-active-class="animated faster slideOutRight">
        <rx-order v-if="headerTip.flag === 0"></rx-order>
    </transition>
</div>
</template>
<script>
import './index.scss'
import { mapGetters } from 'vuex'
import rxOrder from './order'
export default {
    components: {
        rxOrder
    },
    data () {
        return {

        }
    },
    created () {
    },
    methods: {

    },
    computed: {
        ...mapGetters(['userInfo', 'leftInfo', 'headerTip'])
    }
}
</script>
