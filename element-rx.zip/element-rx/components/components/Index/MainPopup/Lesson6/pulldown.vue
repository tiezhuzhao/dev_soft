<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'板块展开关闭'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <div class="analyItem" v-for="index in 1" :key="index">
            <p class="analyItemTit tx-center">展开</p>
            <div class="analyItemCon" :class="{'components-pullwrap': index != pullIndex}">
                <p class="col-md-6" v-for="index in 10" :key="index">
                    <span class="cLightGray">统计</span>
                    <span>0分</span>
                </p>
                <span class="components-pullbtn" @click="pullSwitch(index)"></span>
            </div>
        </div>
        <codemd url="Lesson6/docs/pulldown.md"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {
            pullIndex: undefined
        }
    },
    created () {

    },
    methods: {
        // 展开 关闭切换
        pullSwitch (index) {
            if (this.pullIndex === index) {
                this.pullIndex = undefined
            } else {
                this.pullIndex = index
            }
        }
    }
}
</script>
