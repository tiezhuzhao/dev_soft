<template>
    <div class="layerRtb layerRtb-threecolumn">
        <three-title :title="{name:'提示'}"></three-title>
        <div class="layerRtb-scroll thinScroll" v-scrollHeight="137">
            <div class="analyItem">
                <p class="analyItemTit tx-center">消息提示</p>
                <div class="analyItemCon">
                    <p class="col-md-8">
                        <el-button :plain="true" @click="open">打开消息提示</el-button>
                        <el-button :plain="true" @click="openVn">VNode</el-button>
                    </p>
                </div>
            </div>
            <div class="analyItem">
                <p class="analyItemTit tx-center">弹框</p>
                <div class="analyItemCon">
                    <el-button type="text" @click="open2">点击打开 Message Box</el-button>
                </div>
            </div>
            <div class="analyItem">
                <p class="analyItemTit tx-center">通知</p>
                <div class="analyItemCon">
                    <el-button plain @click="open1">
                        可自动关闭
                    </el-button>
                </div>
            </div>
        </div>
        <div class="layerRtb-footer">
            <div class="analyItem">
                <p class="analyItemTit tx-center">综合</p>
                <div class="analyItemCon">
                    <p class="fl col-md-9"></p>
                    <p class="fr col-md-3">
                        <span class="cLightGray">统计</span>
                        <span class="cGreen fz14 bold">0分</span>
                    </p>
                    <p class="fl"><span class="circlemark circlemark-green">优</span></p>
                </div>
            </div>
            <div class="tx-center">
                <input type="button" class="uiBtn-normal uiBtn-blue" value="确定">
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data () {
        return {}
    },
    created () {},
    methods: {
        open () {
            this.$message('这是一条消息提示')
        },

        openVn () {
            const h = this.$createElement
            this.$message({
                message: h('p', null, [
                    h('span', null, '内容可以是 '),
                    h('i', { style: 'color: teal' }, 'VNode')
                ])
            })
        },
        open2 () {
            this.$alert('这是一段内容', '标题名称', {
                confirmButtonText: '确定',
                callback: action => {
                    this.$message({
                        type: 'info',
                        message: `action: ${action}`
                    })
                }
            })
        },
        open1 () {
            const h = this.$createElement

            this.$notify({
                title: '标题名称',
                message: h('i', {style: 'color: teal'}, '这是提示文案这是提示文案这是提示文案这是提示文案这是提示文案这是提示文案这是提示文案这是提示文案')
            })
        }
    }
}
</script>
