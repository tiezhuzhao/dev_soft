# 部门标识是公共组件里面的区别的唯一标识

## 标识列表

- 商务 `sw`
- 主案 `za`
- 工程 `gc`
- 电商 `ds`
- 平台 `pt`
- 投资 `tz`
- 控股 `kg`

## 使用方法

> 在 use(ElementRx)的时候，传入

```javascript
Vue.use(ElementRx, {
    department: 'za' //部门标识
})
```
