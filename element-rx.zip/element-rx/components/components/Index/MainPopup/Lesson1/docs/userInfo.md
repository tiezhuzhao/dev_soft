# 登录字段标准

> 因为无法保证所有的登录接口的返回字段保持完全一致，所有登录进到我们系统就要保持一致性

## 注意事项 *

1. 所有标准列表里面有的，都要以标准里面的字段进行信息存储, 通常从`query`取的值是字符串 所以统一全部存储的都为字符串。
2. 接口情况: 如调了一个登录接口, 返回的地区字段是`region`,和我们的标准完全不统一。 就需要重新命名之后再存储 `{as_diquId: res.region}`
3. query情况: 通过`query`传的字段，以标准字段去掉 `as_` 为名称传值, 组件内部会匹配标准列表，如果标准列表里面有就会以`{as_+key: value}`的方式进行存储，如果没有就会以`{key:value}`的方式进行存储

## 存值

1. 如果`query`里面包含`save=1`将会自动存储信息
2. 不管那种方式登录都会把信息存储在vuex的`userInfo`

## fg && ct 传值规范

> `fg` 是不是城 , `ct` 地区id

- 如果 `fg == 1` 那么 `ct` 就是城id
- 如果 `fg == 0` 那么 `ct` 就是地区id
- 如果 `ct == 0 && fg == 0` 就是全部的

## 登录详情字段标准

```javascript
{String} as_diquId: '11' // 登录人地区
{String} as_diquName: 'R6' //登录人地区名称
{String} as_cardNo: '01012323' //卡号
{String} as_password: '01012323' //密码
{String} as_appId: '8fb6ebb7-43c8-4478-abc3-04da9d932852' //AppId
{String} as_jueseId: '121' //角色id
{String} as_jueseName: 'xx主案' //角色name
{String} as_fullName: '王三' //姓名
{String} as_type: '' //特殊字段 区分不同
{String} as_fg: '0' || '1' // 1是城市 0 不是城市
{String} as_ct: '1' // 城id 如果 as_fg == 1 那么 as_ct就是城id 反之就是正常的地区id
{String} as_userImg: 'https://invest01.oss-cn-beijing.aliyuncs.com/rs/1551159685143.jpg' // 登录人头像地址
```
