# 左侧栏统一常用字段

> 左侧列表现在做不到全部统一(大概原因是，各个大业务的主单表命名不一致，解决方案: 为了减轻重命名的成本，每个大业务的所有字段都要一致。)

## 注意事项 *

1. 所有系统的常用的左侧列表字段要**完全一致**, 包括**返回类型**
2. 如果现在的没有这个字段需要加上。
3. 以前的字段名称不要删除 兼容老数据

### 示例（主案业务系统）

```javascript
{String} ci_RwdId: "11-199839"  //单号
{String} ci_DesignerName: "郭小兵" //设计师姓名
{String} ci_DesignerCard: "01010954" //设计师卡号
{String} ci_ClientName: "都润生态环境有限公司" //项目名称
{Number} ci_Stage: 6  //阶段
{Number} tb_diqu: 11 //地区
{Number} signs: 1 //正常 异常 问题
{String} ai_AppId: '8fb6ebb7-43c8-4478-abc3-04da9d932852' //AppId
```

### 示例 (主案设计院系统)

```javascript
{String} DO_OrderNo: "11-199839-S-1"  //单号
{String} DO_Creator: "郭小兵" //设计师姓名
{String} DO_CreatorCard: "01010954" //设计师卡号
{String} DO_GraphicDesignerName: "郭小兵" //绘图员姓名
{String} DO_GraphicDesignerCard: "01010954" //绘图员卡号
{Number} DO_StatusName:  //订单状态,
{Number} DO_DrawingType: 1 //类型
{String} DO_GroupId: 36 // 所id
{String} group_name: "成都设计所" //所名字
{String} BI_ProjectName:"南京爱亚时尚文化传播有限公司" //项目名称
```
