<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'登录信息标准字段'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <codemd url="Lesson1/docs/userInfo.md"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {

        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
