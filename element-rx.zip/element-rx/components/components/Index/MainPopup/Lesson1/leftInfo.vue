<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'左侧列表标准字段'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <codemd url="Lesson1/docs/leftInfo.md"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {

        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
