<template>
    <div class="layerRtb layerRtb-threecolumn">
        <three-title :title="{name:'数字类'}"></three-title>
        <div class="layerRtb-scroll thinScroll" v-scrollHeight="0">
            <div class="analyItem">
                <p class="analyItemTit tx-center">数字</p>
                <div class="analyItemCon">
                    <div class="col-md-12 relative">
                        <span class="pr8">数字转换为大写金额</span><span>{{number1}} / {{number1 | capitalizeAmount}}</span>
                    </div>
                    <div class="col-md-12 relative">
                        <span class="pr8">数字截取小数点</span><span>{{number2}} / {{number2 | toFixed(4)}} 括号中为小数点的后几位</span>
                    </div>
                </div>
            </div>
            <codemd url="Lesson3/docs/number.md"></codemd>
        </div>
    </div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {
            number1: 123,
            number2: 666.6666333
        }
    },
    mounted () {},
    methods: {}
}
</script>
