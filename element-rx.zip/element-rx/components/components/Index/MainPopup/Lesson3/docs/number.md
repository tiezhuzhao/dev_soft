```html
<template>
    <div class="analyItem">
        <p class="analyItemTit tx-center">数字</p>
        <div class="analyItemCon">
            <div class="col-md-12 relative">
                <span class="pr8">数字转换为大写金额</span><span>{{number1}} / {{number1 | capitalizeAmount}}</span>
            </div>
            <div class="col-md-12 relative">
                <span class="pr8">数字截取小数点</span><span>{{number2}} / {{number2 | toFixed(4)}} 括号中为小数点的后几位</span>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data () {
        return {
            number1: 123,
            number2: 666.6666333
        }
    },
    created () {

    },
    methods: {

    }
}
</script>
```
