```html
<template>
    <!-- MainRight.vue -->
    <!-- 当你点击列表弹出列表窗口得时候，你需要调用一个方法发送消息 -->
    <router-link @click.native="$functions.postParentMessage({title: false})">列表</router-link>

    <!-- List.vue -->
    <!-- 当你列表返回的时候，你需要调用一个方法发送消息 -->
    <router-link @click.native="$functions.postParentMessage({title: true})">
        <input type="button" class="uiBtn-normal uiBtn-orange fl" value="返回">
    </router-link>
</template>
```

<!-- split block -->

```html
<!-- 通信代码，你可点击上方 查看代码，查看源代码 -->
<script src="https://zstatic.rxjy.com/element-rx/packages-browser/message/index.js"></script>
<script>
    // 隐藏标题
    postParentMessage({title: false})
    // 显示标题
    postParentMessage({title: true})
</script>
```
