<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'隐藏显示主轴标题'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <h3 class="cBlue mb20">你可以点击主轴项目的 '嵌套' 测试该功能</h3>
        <h3 class="mb10">Vue 调用方法</h3>
        <el-alert
            title="或许有可能其他情况导致列表关闭，你需要在列表也监听路由变化，当变化的时候，调用方法 "
            type="warning">
        </el-alert>
        <codemd url="Lesson7/docs/close-title.md" index="0"></codemd>
        <h3 class="mb10 mt10">
            <span>JS 调用方法</span>
            <a class="cBlue" target="_blank" href="https://zstatic.rxjy.com/element-rx/packages-browser/message/index.js">查看代码</a>
        </h3>
        <codemd url="Lesson7/docs/close-title.md" index="1"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {

        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
