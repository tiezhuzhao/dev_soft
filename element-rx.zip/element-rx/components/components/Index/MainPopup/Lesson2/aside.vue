<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'左侧栏布局'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <h3>组件使用</h3>
        <codemd url="Lesson2/docs/aside.md"></codemd>
        <h3 class="mb10 mt10">参数配置</h3>
        <table class="uiTable">
            <tr>
                <th>参数</th>
                <th>说明</th>
            </tr>
            <tr>
                <td>slideBar</td>
                <td>列表数据格式</td>
            </tr>
            <tr>
                <td>menuInit</td>
                <td>默认选中左侧的项, 如果想让那一项选中传该项的menuFlag值</td>
            </tr>
        </table>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {

        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
