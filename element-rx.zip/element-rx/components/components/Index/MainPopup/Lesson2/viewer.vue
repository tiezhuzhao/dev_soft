<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'图片放大'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <rx-viewer :images="data">
            <div class="clearfix">
                <div class="col-md-4" v-for="(item, index) of data" :key="index">
                    <img :src="item | smallImg(100, 100)" :alt="index">
                </div>
            </div>
        </rx-viewer>
        <codemd url="Lesson2/docs/viewer.md"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {
            data: []
        }
    },
    mounted () {
        // 模拟数据延迟
        setTimeout(() => {
            this.data = [
                'http://wenes01.oss-cn-beijing.aliyuncs.com/Project/Image/2017/10/20/14291087049232.jpg',
                'http://wenes01.oss-cn-beijing.aliyuncs.com/Project/Image/2017/10/20/14291087049232.jpg',
                'http://wenes01.oss-cn-beijing.aliyuncs.com/Project/Image/2017/10/20/14291087049232.jpg'
            ]
        }, 1000)
    },
    methods: {

    }
}
</script>
