```html
<template>
    <rx-viewer :images="data">
        <div class="clearfix">
            <div class="col-md-4" v-for="(item, index) of data" :key="index">
                <img :src="item | smallImg(100, 100)" :alt="index">
            </div>
        </div>
    </rx-viewer>
</template>
<script>
export default {
    data () {
        return {
            data: []
        }
    },
    created () {
        // 模拟数据延迟
        setTimeout(() => {
            this.data = [
                'http://wenes01.oss-cn-beijing.aliyuncs.com/Project/Image/2017/10/20/14291087049232.jpg',
                'http://wenes01.oss-cn-beijing.aliyuncs.com/Project/Image/2017/10/20/14291087049232.jpg',
                'http://wenes01.oss-cn-beijing.aliyuncs.com/Project/Image/2017/10/20/14291087049232.jpg'
            ]
        }, 1000)
    },
    methods: {

    }
}
</script>
```
