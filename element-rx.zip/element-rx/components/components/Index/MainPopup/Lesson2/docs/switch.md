```html
<template>
    <div class="col-md-6 relative">
        禁用
        <rx-switch disabled="disabled" label="禁用"></rx-switch>
    </div>
    <div class="col-md-12 relative mt10">
        <p class="col-md-12">切换结果{{dataAry}}</p>
        <p class="col-md-3 relative" v-for="(item, index) of dataAry" :key="index">
            {{item.name}}
            <rx-switch v-model="item.state" :label="item.name"></rx-switch>
        </p>
    </div>
</template>
<script>
export default {
    data () {
        return {
            dataAry: [
                {name: '模块一', state: -1},
                {name: '模块二', state: 1},
                {name: '模块三', state: 0},
                {name: '模块四'}
            ]
        }
    },
    created () {

    },
    methods: {

    }
}
</script>
```
