```html
<template>
    <three-title :title="{name:'三段头部标题'}"></three-title>
</template>
<script>
export default {
    data () {
        return {

        }
    },
    created () {

    },
    methods: {

    }
}
</script>
```
