```html
<template>
    <rx-editor
        v-model="content"
        :elStyle="{height: '250px'}"
        :init="{class: 1, mime: 1}"
        :options="{}">
    </rx-editor>
</template>
<script>
import rxEditor from '@rx/packages/editor/Index'
export default {
    components: {
        rxEditor
    },
    data () {
        return {
            content: ''
        }
    },
    created () {
        // 模拟数据延迟
        setTimeout(() => {
            this.content = '<p>测试数据</p>'
        }, 2000)
    },
    methods: {

    }
}
</script>
```
