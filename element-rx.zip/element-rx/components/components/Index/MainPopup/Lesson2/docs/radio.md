```html
<template>
    <div class="col-md-6 relative">
        禁用
        <rx-radio disabled="disabled" label="禁用"></rx-radio>
    </div>
    <div class="col-md-12 relative mt10">
        <p class="col-md-12 cRed">单选结果 ： {{radioCheck}}</p>
        <p class="col-md-3 relative lh28" v-for="(item, index) of dataAry" :key="index">
            {{item}}
            <rx-radio v-model="radioCheck" :label="item"></rx-radio>
        </p>
    </div>
</template>
<script>
export default {
    data () {
        return {
            dataAry: ['模块一', '模块二', '模块三', '模块四'],
            radioCheck: '模块一'
        }
    },
    created () {

    },
    methods: {

    }
}
</script>
```
