```html
<template>
    <div class="col-md-6 relative">
        禁用
        <rx-checkbox disabled="disabled" label="禁用"></rx-checkbox>
    </div>
    <div class="col-md-12 relative mt10">
        <p class="col-md-12 cRed">绑定数组： {{checkboxCheck}}</p>
        <p class="col-md-3 relative lh28" v-for="(item, index) of dataAry" :key="index">
            {{item.name}}
            <rx-checkbox v-model="checkboxCheck" :label="item"></rx-checkbox>
        </p>
    </div>
</template>
<script>
export default {
    data () {
        return {
            dataAry: [
                {name: '模块一', state: -1},
                {name: '模块二', state: 1},
                {name: '模块三', state: 0},
                {name: '模块四'}
            ],
            checkboxCheck: [{name: '模块四'}]
        }
    },
    created () {

    },
    methods: {

    }
}
</script>
```
