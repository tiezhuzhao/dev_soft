```html
<template>
    <rx-header :header="header"></rx-header>
</template>
<script>
export default {
    data () {
        return {
            header: {
                title: '集团布局',
                list: [
                    {
                        name: '订单', // 名称
                        flag: 0, // 项标识
                        count: 2, // 消息个数
                        icon: 'https://pa.rxjy.com/abc/images/header/order.png', // 图片路径/类名
                    },
                    {
                        name: '消息',
                        flag: 1,
                        count: 0,
                        icon: 'https://pa.rxjy.com/abc/images/header/order.png'
                    }
                ]
            }
        }
    },
    created () {

    },
    methods: {

    }
}
</script>
```
