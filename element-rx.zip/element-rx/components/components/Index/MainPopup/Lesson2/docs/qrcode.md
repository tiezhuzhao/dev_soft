```html
<template>
    <div class="col-md-4" v-for="(item, index) of list" :key="index" >
        <rx-qrcode :value="item" :options="{width: 50}"></rx-qrcode>
    </div>
</template>
<script>
import rxQrcode from '@rx/packages/qrcode/Index'
export default {
    components: {
        rxQrcode
    },
    data () {
        return {
            list: [
                {
                    cn: '无法访问此网站',
                    en: 'This site can’t be reached'
                },
                {
                    cn: '无法访问此网站',
                    en: 'This site can’t be reached'
                },
                {
                    cn: '无法访问此网站',
                    en: 'This site can’t be reached'
                }
            ]
        }
    },
    created () {

    },
    methods: {

    }
}
</script>
```
