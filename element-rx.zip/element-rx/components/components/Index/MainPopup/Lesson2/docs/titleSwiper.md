```html
<template>
    <rx-center-title-swiper :data="title">
        <ul class="clearfix uiTab9 j_uiTab9">
            <li v-for="(item, index) of title" :key="index"
                :class="{'uiTab9-active':subIndex == index}"
                @click="subSwitch(index)">
                {{item}}
            </li>
        </ul>
    </rx-center-title-swiper>
</template>
<script>
export default {
    data () {
        return {
            subIndex: 1,
            title: ['状', '文档', '组件', '过滤器', '指令', '工具类', '组逻', '方法', 'ELE', '占位', '最后']
        }
    },
    created () {

    },
    methods: {
        subSwitch (index) {
            this.subIndex = index
        }
    }
}
</script>
```
