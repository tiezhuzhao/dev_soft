```html
<template>
    <rx-aside :slideBar="slideBar" :menuInit="{menuFlag: 5}"></rx-aside>
</template>
<script>
export default {
    data () {
        return {
            // slideBar 传值对象
            slideBar: [
                { // 一级切换tab
                    name: '一栏',
                    list: [
                        {
                            name: '项目', // 侧栏展开时展示的名称
                            na: '项', // 侧栏关闭时展示的名称
                            link: `/ElementRx/Index`, // 点击侧栏项跳转的路由
                            menuFlag: 0 // 该项的唯一标书
                        },
                        {
                            name: '跳转百度',
                            na: '百',
                            link: `https://www.baidu.com/`, // 如果以http开头，将会新开窗口
                            menuFlag: 3
                        }
                    ]
                },
                {
                    name: '二栏',
                    list: [
                        {
                            name: '多栏',
                            na: '多',
                            menuFlag: [5, 6], // 如果该项下有二级，此为所有二级的menuFlag数组
                            children: [
                                {
                                    name: '第一项',
                                    link: `/ElementRx/Layout?index=1`,
                                    menuFlag: 5
                                },
                                {
                                    name: '嵌套',
                                    link: `/ElementRx/Layout?index=2`,
                                    menuFlag: 6,
                                    iframe: true // 此页面是否为嵌套
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    },
    created () {

    },
    methods: {

    }
}
</script>
```
