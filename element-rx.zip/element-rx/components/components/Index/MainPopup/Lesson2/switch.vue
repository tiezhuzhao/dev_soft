<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'切换判断'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <div class="analyItem">
            <p class="analyItemTit tx-center">切换</p>
            <div class="analyItemCon">
                <div class="col-md-6 relative">
                    禁用
                    <rx-switch disabled="disabled" label="禁用"></rx-switch>
                </div>
                <div class="col-md-12 relative mt10">
                    <p class="col-md-12">切换结果{{dataAry}}</p>
                    <p class="col-md-3 relative" v-for="(item, index) of dataAry" :key="index">
                        {{item.name}}
                        <rx-switch v-model="item.state" :label="item.name"></rx-switch>
                    </p>
                </div>
            </div>
        </div>
        <codemd url="Lesson2/docs/switch.md"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {
            dataAry: [
                {name: '模块一', state: -1},
                {name: '模块二', state: 1},
                {name: '模块三', state: 0},
                {name: '模块四'}
            ]
        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
