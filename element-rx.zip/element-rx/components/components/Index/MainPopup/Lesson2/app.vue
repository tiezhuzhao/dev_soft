<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'主容器布局'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <h3>组件使用</h3>
        <codemd url="Lesson2/docs/app.md"></codemd>
        <h3 class="mb10 mt10">参数配置</h3>
        <table class="uiTable">
            <tr>
                <th>参数</th>
                <th>说明</th>
                <th>类型</th>
                <th>默认值</th>
            </tr>
            <tr>
                <td>cutting</td>
                <td>隐藏头部和侧栏</td>
                <td>true/false</td>
                <td>flase</td>
            </tr>
        </table>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {

        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
