<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'单选判断'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <div class="analyItem">
            <p class="analyItemTit tx-center">单选</p>
            <div class="analyItemCon">
                <div class="col-md-6 relative">
                    禁用
                    <rx-radio disabled="disabled" label="禁用"></rx-radio>
                </div>
                <div class="col-md-12 relative mt10">
                    <p class="col-md-12 cRed">单选结果 ： {{radioCheck}}</p>
                    <p class="col-md-3 relative lh28" v-for="(item, index) of dataAry" :key="index">
                        {{item}}
                        <rx-radio v-model="radioCheck" :label="item"></rx-radio>
                    </p>
                </div>
            </div>
        </div>
        <codemd url="Lesson2/docs/radio.md"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {
            dataAry: ['模块一', '模块二', '模块三', '模块四'],
            radioCheck: '模块一'
        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
