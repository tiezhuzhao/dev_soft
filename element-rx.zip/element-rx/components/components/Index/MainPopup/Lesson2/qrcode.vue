<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'二维码'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <div class="col-md-4" v-for="(item, index) of list" :key="index" >
            <rx-qrcode :value="item" :options="{width: 50}"></rx-qrcode>
        </div>
        <codemd url="Lesson2/docs/qrcode.md"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
import rxQrcode from '@rx/packages/qrcode/Index'
export default {
    components: {
        codemd,
        rxQrcode
    },
    data () {
        return {
            list: [
                {
                    cn: '无法访问此网站',
                    en: 'This site can’t be reached'
                },
                {
                    cn: '无法访问此网站',
                    en: 'This site can’t be reached'
                },
                {
                    cn: '无法访问此网站',
                    en: 'This site can’t be reached'
                }
            ]
        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
