<template>
<div class="layerRtb layerRtb-threecolumn">
    <three-title :title="{name:'三段头部标题'}"></three-title>
    <div class="layerRtb-scroll thinScroll" v-scrollHeight = "0">
        <three-title :title="{name:'返回组件'}"></three-title>
        <codemd url="Lesson2/docs/threeTitle.md"></codemd>
    </div>
</div>
</template>
<script>
import codemd from '../code-md'
export default {
    components: {
        codemd
    },
    data () {
        return {

        }
    },
    mounted () {

    },
    methods: {

    }
}
</script>
