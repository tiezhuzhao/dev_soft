<template>
<div class="uiTab9Con">
    <div class="pr10">
        <div class="analyItem">
            <p class="analyItemTit tx-center">状态</p>
            <div class="analyItemCon"></div>
        </div>
    </div>
    <div class="pr10 thinScroll" v-scrollHeight="10">
        <router-link tag="div" :to="routerPath('lesson4-scroll')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">滚动</p>
            <div class="analyItemCon">
                滚条条高度
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson4-toolstip')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">提示</p>
            <div class="analyItemCon">
                划过提示
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson4-types')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">类型</p>
            <div class="analyItemCon">
                input限制输入类型
            </div>
        </router-link>
    </div>
</div>
</template>
<script>
export default {
    data () {
        return {

        }
    },
    created () {

    },
    methods: {
        // 路由跳转路径拼接
        routerPath (path) {
            return this.$route.matched[1].path + '/' + path
        },
        // 直接进行路由跳转路径
        routerPush (path) {
            this.$router.push(this.$route.matched[1].path + '/' + path)
        }
    }
}
</script>
