<template>
<div class="uiTab9Con">
    <div class="pr10">
        <div class="analyItem">
            <p class="analyItemTit tx-center">状态</p>
            <div class="analyItemCon"></div>
        </div>
    </div>
    <div class="pr10 thinScroll" v-scrollHeight="10">
        <router-link tag="div" :to="routerPath('lesson6-icons')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">图标</p>
            <div class="analyItemCon">
                常用图标
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson6-switch')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">切换</p>
            <div class="analyItemCon">
                编辑和不可编辑切换
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson6-pulldown')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">展关</p>
            <div class="analyItemCon">
                板块展开关闭
            </div>
        </router-link>
    </div>
</div>
</template>
<script>
export default {
    data () {
        return {

        }
    },
    created () {

    },
    methods: {
        // 路由跳转路径拼接
        routerPath (path) {
            return this.$route.matched[1].path + '/' + path
        },
        // 直接进行路由跳转路径
        routerPush (path) {
            this.$router.push(this.$route.matched[1].path + '/' + path)
        }
    }
}
</script>
