<template>
<div class="uiTab9Con">
    <div class="pr10">
        <div class="analyItem">
            <p class="analyItemTit tx-center">状态</p>
            <div class="analyItemCon"></div>
        </div>
    </div>
    <div class="pr10 thinScroll" v-scrollHeight="10">
        <router-link tag="div" :to="routerPath('lesson5-date')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">时间</p>
            <div class="analyItemCon">
                时间类
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson5-dom')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">元素</p>
            <div class="analyItemCon">
                操作dom类
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson5-number')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">数字</p>
            <div class="analyItemCon">
                数字类
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson5-storage')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">存储</p>
            <div class="analyItemCon">
                本地存储类
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson5-string')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">字符串类</p>
            <div class="analyItemCon">
                字符串类
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson5-types')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">类型</p>
            <div class="analyItemCon">
                类型验证类
            </div>
        </router-link>
    </div>
</div>
</template>
<script>
export default {
    data () {
        return {

        }
    },
    created () {

    },
    methods: {
        // 路由跳转路径拼接
        routerPath (path) {
            return this.$route.matched[1].path + '/' + path
        },
        // 直接进行路由跳转路径
        routerPush (path) {
            this.$router.push(this.$route.matched[1].path + '/' + path)
        }
    }
}
</script>
