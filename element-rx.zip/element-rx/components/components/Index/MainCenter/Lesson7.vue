<template>
<div class="uiTab9Con">
    <div class="pr10">
        <div class="analyItem">
            <p class="analyItemTit tx-center">状态</p>
            <div class="analyItemCon"></div>
        </div>
    </div>
    <div class="pr10 thinScroll" v-scrollHeight="10">
        <router-link tag="div" :to="routerPath('lesson7-closeTitle')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">关闭</p>
            <div class="analyItemCon">
                隐藏显示主轴标题
            </div>
        </router-link>
    </div>
</div>
</template>
<script>
export default {
    data () {
        return {

        }
    },
    created () {

    },
    methods: {
        // 路由跳转路径拼接
        routerPath (path) {
            return this.$route.matched[1].path + '/' + path
        },
        // 直接进行路由跳转路径
        routerPush (path) {
            this.$router.push(this.$route.matched[1].path + '/' + path)
        }
    }
}
</script>
