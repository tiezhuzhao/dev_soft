<template>
    <div class="uiTab9Con">
        <div class="pr10">
            <div class="analyItem">
                <p class="analyItemTit tx-center">状态</p>
                <div class="analyItemCon"></div>
            </div>
        </div>
        <div class="pr10 thinScroll" v-scrollHeight="10">
            <router-link tag="div" :to="routerPath('lesson8-Basic')" class="analyItem anItemBor" active-class="anItemBor-active">
                <p class="analyItemTit tx-center">基础</p>
                <div class="analyItemCon">
                    基础类样式展示以及覆盖
                </div>
            </router-link>
            <router-link tag="div" :to="routerPath('lesson8-Data')" class="analyItem anItemBor" active-class="anItemBor-active">
                <p class="analyItemTit tx-center">数据</p>
                <div class="analyItemCon">
                    数据类样式展示以及覆盖
                </div>
            </router-link>
            <router-link tag="div" :to="routerPath('lesson8-Form')" class="analyItem anItemBor" active-class="anItemBor-active">
                <p class="analyItemTit tx-center">表单</p>
                <div class="analyItemCon">
                   表单类样式展示以及覆盖
                    <!-- 包括 '单选框' '多选框' '输入框' '计数器' '选择器' '级联选择器' '开关' '滑块' '时间选择器' '日期选择器' '日期和时间选择器' '上传'
                '评分' '颜色选择器' '穿梭框' '表单' -->
                </div>
            </router-link>
            <router-link tag="div" :to="routerPath('lesson8-Navigation')" class="analyItem anItemBor" active-class="anItemBor-active">
                <p class="analyItemTit tx-center">导航</p>
                <div class="analyItemCon">
                    导航类样式展示以及覆盖
                </div>
            </router-link>
            <router-link tag="div" :to="routerPath('lesson8-Notice')" class="analyItem anItemBor" active-class="anItemBor-active">
                <p class="analyItemTit tx-center">提示</p>
                <div class="analyItemCon">
                    提示类样式展示以及覆盖
                </div>
            </router-link>
            <router-link tag="div" :to="routerPath('lesson8-Others')" class="analyItem anItemBor" active-class="anItemBor-active">
                <p class="analyItemTit tx-center">其他</p>
                <div class="analyItemCon">
                    其他类样式展示以及覆盖
                </div>
            </router-link>
        </div>
    </div>
</template>
<script>
export default {
    data () {
        return {}
    },
    created () {},
    methods: {
    // 路由跳转路径拼接
        routerPath (path) {
            return this.$route.matched[1].path + '/' + path
        },
        // 直接进行路由跳转路径
        routerPush (path) {
            this.$router.push(this.$route.matched[1].path + '/' + path)
        }
    }
}
</script>
