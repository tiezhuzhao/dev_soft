<template>
<div class="uiTab9Con">
    <div class="pr10">
        <div class="analyItem">
            <p class="analyItemTit tx-center">状态</p>
            <div class="analyItemCon"></div>
        </div>
    </div>
    <div class="pr10 thinScroll" v-scrollHeight="10">
        <div class="analyItem">
            <p class="analyItemTit tx-center">文档</p>
            <div class="analyItemCon link">
                <p class="col-md-12">
                    <a target="_" href="https://rxued.github.io/ui/component.html#list1">瑞祥ui全局组件</a>
                </p>
                <p class="col-md-12">
                    <a target="_" href="https://zstatic.rxjy.com/element-rx/static/basics/">其他标准模板 -> 打开wps指挥平台的标准</a>
                </p>
                <p class="col-md-12">
                    <a target="_" href="http://layer.layui.com/">layer弹出层官方文档</a>
                </p>
                <p class="col-md-12">
                    <a target="_" href="http://element.eleme.io/#/zh-CN/component/installation">Element-ui组件布局文档</a>
                </p>
                <p class="col-md-12">
                    <a target="_" href="https://zstatic.rxjy.com/element-rx/static/icons/iconfont/demo_index.html">字体图标库文档</a>
                </p>
            </div>
        </div>
        <router-link tag="div" :to="routerPath('lesson1-leftInfo')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">左侧</p>
            <div class="analyItemCon">
                左侧列表标准字段
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson1-userInfo')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">登录</p>
            <div class="analyItemCon">
                登录信息标准字段
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson1-department')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">标识</p>
            <div class="analyItemCon">
                全局部门标识
            </div>
        </router-link>
    </div>
</div>
</template>
<script>
export default {
    data () {
        return {

        }
    },
    created () {

    },
    methods: {
        // 路由跳转路径拼接
        routerPath (path) {
            return this.$route.matched[1].path + '/' + path
        },
        // 直接进行路由跳转路径
        routerPush (path) {
            this.$router.push(this.$route.matched[1].path + '/' + path)
        }
    }
}
</script>
<style lang="scss" scoped>
a {
    text-decoration: underline;
    color: blue
}
</style>
