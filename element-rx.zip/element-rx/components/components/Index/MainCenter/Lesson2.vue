<template>
<div class="uiTab9Con">
    <div class="pr10">
        <div class="analyItem">
            <p class="analyItemTit tx-center">状态</p>
            <div class="analyItemCon"></div>
        </div>
    </div>
    <div class="pr10 thinScroll" v-scrollHeight="10">
        <router-link tag="div" :to="routerPath('lesson2-app')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">主容器</p>
            <div class="analyItemCon">
                rx-app 主容器布局
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-main')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">主内容</p>
            <div class="analyItemCon">
                rx-main 主内容布局
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-aside')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">侧栏</p>
            <div class="analyItemCon">
                rx-aside 左侧栏布局
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-header')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">头部</p>
            <div class="analyItemCon">
                rx-header 头部栏布局
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-radio')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">单选</p>
            <div class="analyItemCon">
                rx-radio 单选判断
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-checkbox')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">多选</p>
            <div class="analyItemCon">
                rx-checkbox 多选判断
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-switch')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">切换</p>
            <div class="analyItemCon">
                rx-switch 切换判断
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-threeTitle')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">三段标题</p>
            <div class="analyItemCon">
                three-title 三段头部标题
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-titleSwiper')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">二段标题</p>
            <div class="analyItemCon">
                rx-center-title-swiper 二段标题切换
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-upload')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">上传</p>
            <div class="analyItemCon">
                rx-upload 上传
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-viewer')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">图片放大</p>
            <div class="analyItemCon">
                rx-viewer 图片放大
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-qrcode')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">二维码</p>
            <div class="analyItemCon">
                qrcode 二维码
            </div>
        </router-link>
        <router-link tag="div" :to="routerPath('lesson2-editor')" class="analyItem anItemBor" active-class="anItemBor-active">
            <p class="analyItemTit tx-center">编辑器</p>
            <div class="analyItemCon">
                editor 编辑器
            </div>
        </router-link>
    </div>
</div>
</template>
<script>
export default {
    data () {
        return {

        }
    },
    created () {

    },
    methods: {
        // 路由跳转路径拼接
        routerPath (path) {
            return this.$route.matched[1].path + '/' + path
        },
        // 直接进行路由跳转路径
        routerPush (path) {
            this.$router.push(this.$route.matched[1].path + '/' + path)
        }
    }
}
</script>
