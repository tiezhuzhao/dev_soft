// 测试用例 不要使用
export const SET_DEMO = 'SET_DEMO'
