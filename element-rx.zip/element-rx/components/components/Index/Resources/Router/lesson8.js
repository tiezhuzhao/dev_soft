export default [
    {
        path: 'lesson8-Basic',
        component: () => import('../../MainPopup/Lesson8/Basic.vue')
    },
    {
        path: 'lesson8-Data',
        component: () => import('../../MainPopup/Lesson8/Data.vue')
    },
    {
        path: 'lesson8-Form',
        component: () => import('../../MainPopup/Lesson8/Form.vue')
    },
    {
        path: 'lesson8-Navigation',
        component: () => import('../../MainPopup/Lesson8/Navigation.vue')
    },
    {
        path: 'lesson8-Notice',
        component: () => import('../../MainPopup/Lesson8/Notice.vue')
    },
    {
        path: 'lesson8-Others',
        component: () => import('../../MainPopup/Lesson8/Others.vue')
    }
]
