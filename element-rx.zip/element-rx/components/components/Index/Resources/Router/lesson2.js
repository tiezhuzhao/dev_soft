export default [
    {
        path: 'lesson2-app',
        component: () => import('../../MainPopup/Lesson2/app.vue')
    },
    {
        path: 'lesson2-main',
        component: () => import('../../MainPopup/Lesson2/main.vue')
    },
    {
        path: 'lesson2-aside',
        component: () => import('../../MainPopup/Lesson2/aside.vue')
    },
    {
        path: 'lesson2-header',
        component: () => import('../../MainPopup/Lesson2/header.vue')
    },
    {
        path: 'lesson2-radio',
        component: () => import('../../MainPopup/Lesson2/radio.vue')
    },
    {
        path: 'lesson2-checkbox',
        component: () => import('../../MainPopup/Lesson2/checkbox.vue')
    },
    {
        path: 'lesson2-switch',
        component: () => import('../../MainPopup/Lesson2/switch.vue')
    },
    {
        path: 'lesson2-threeTitle',
        component: () => import('../../MainPopup/Lesson2/threeTitle.vue')
    },
    {
        path: 'lesson2-titleSwiper',
        component: () => import('../../MainPopup/Lesson2/titleSwiper.vue')
    },
    {
        path: 'lesson2-upload',
        component: () => import('../../MainPopup/Lesson2/upload.vue')
    },
    {
        path: 'lesson2-viewer',
        component: () => import('../../MainPopup/Lesson2/viewer.vue')
    },
    {
        path: 'lesson2-qrcode',
        component: () => import('../../MainPopup/Lesson2/qrcode.vue')
    },
    {
        path: 'lesson2-editor',
        component: () => import('../../MainPopup/Lesson2/editor.vue')
    }
]
