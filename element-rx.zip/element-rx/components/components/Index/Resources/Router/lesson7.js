export default [
    {
        path: 'lesson7-closeTitle',
        component: () => import('../../MainPopup/Lesson7/closeTitle.vue')
    }
]
