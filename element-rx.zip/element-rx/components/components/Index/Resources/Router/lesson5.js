export default [
    {
        path: 'lesson5-date',
        component: () => import('../../MainPopup/Lesson5/date.vue')
    },
    {
        path: 'lesson5-dom',
        component: () => import('../../MainPopup/Lesson5/dom.vue')
    },
    {
        path: 'lesson5-number',
        component: () => import('../../MainPopup/Lesson5/number.vue')
    },
    {
        path: 'lesson5-storage',
        component: () => import('../../MainPopup/Lesson5/storage.vue')
    },
    {
        path: 'lesson5-string',
        component: () => import('../../MainPopup/Lesson5/string.vue')
    },
    {
        path: 'lesson5-types',
        component: () => import('../../MainPopup/Lesson5/types.vue')
    }
]
