export default [
    {
        path: 'lesson1-leftInfo',
        component: () => import('../../MainPopup/Lesson1/leftInfo.vue')
    },
    {
        path: 'lesson1-userInfo',
        component: () => import('../../MainPopup/Lesson1/userInfo.vue')
    },
    {
        path: 'lesson1-department',
        component: () => import('../../MainPopup/Lesson1/department.vue')
    }
]
