export default [
    {
        path: 'lesson4-scroll',
        component: () => import('../../MainPopup/Lesson4/scroll.vue')
    },
    {
        path: 'lesson4-toolstip',
        component: () => import('../../MainPopup/Lesson4/toolstip.vue')
    },
    {
        path: 'lesson4-types',
        component: () => import('../../MainPopup/Lesson4/types.vue')
    }
]
