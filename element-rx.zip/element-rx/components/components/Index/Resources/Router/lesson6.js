export default [
    {
        path: 'lesson6-icons',
        component: () => import('../../MainPopup/Lesson6/icons.vue')
    },
    {
        path: 'lesson6-switch',
        component: () => import('../../MainPopup/Lesson6/switch.vue')
    },
    {
        path: 'lesson6-pulldown',
        component: () => import('../../MainPopup/Lesson6/pulldown.vue')
    }
]
