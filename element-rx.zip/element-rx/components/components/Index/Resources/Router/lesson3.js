export default [
    {
        path: 'lesson3-number',
        component: () => import('../../MainPopup/Lesson3/number.vue')
    },
    {
        path: 'lesson3-string',
        component: () => import('../../MainPopup/Lesson3/string.vue')
    },
    {
        path: 'lesson3-others',
        component: () => import('../../MainPopup/Lesson3/others.vue')
    }
]
