import Vue from 'vue'
import Router from 'vue-router'
import configRx from '@config/index.rx'

import Index from '../components/Index/Resources/Router/index'
import Layout from '../components/Layout/Resources/Router/index'

Vue.use(Router)

export default new Router({
    mode: configRx.mode,
    base: configRx.base,
    routes: [
        {
            path: '/',
            redirect: '/ElementRx'
        },
        {
            path: '/ElementRx',
            redirect: '/ElementRx/Layout',
            component: () => import('../components/Entry.vue'),
            children: [
                { // 模板-功能
                    path: 'Index',
                    component: () => import('../components/Index/Index.vue'),
                    children: Index
                },
                { // 模板-布局
                    path: 'Layout',
                    component: () => import('../components/Layout/Index.vue'),
                    children: Layout
                },
                { // 模板-布局
                    path: 'Iframe',
                    component: () => import('../components/Iframes/communication.vue')
                }
            ]
        },
        {
            path: '404',
            component: require('@rx/coreRouter/404.vue').default
        },
        {
            path: '*',
            component: require('@rx/coreRouter/redirect.vue').default
        }
    ]
})
