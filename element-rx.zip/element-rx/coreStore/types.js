// 设置插件公共状态状态
export const SET_RX = `SET_RX`
// 设置缓存和清除缓存
export const SET_CACHE_STATE = `SET_CACHE_STATE`
// 设置更新左侧列表
export const SET_UPDATE_LEFT = `SET_UPDATE_LEFT`
// 设置更新回访
export const SET_UPDATE_VISIT = `SET_UPDATE_VISIT`
// 更新二段板块
export const SET_UPDATE_PLATE = `SET_UPDATE_PLATE`
// 左侧列表数据
export const SET_LEFT_INFO = `SET_LEFT_INFO`
// 设置用户信息
export const SET_USER_INFO = `SET_USER_INFO`
// 二段传值到三段
export const SET_TWO_TO_THREE_INFO = `SET_TWO_TO_THREE_INFO`
// 设置头部tip点击信息
export const SET_HEADER_TIP = `SET_HEADER_TIP`
// 设置左侧当前选中信息
export const SET_ASIDE_CUR = `SET_ASIDE_CUR`
