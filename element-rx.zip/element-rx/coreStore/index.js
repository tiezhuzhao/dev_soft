import * as types from './types'
import utils from '../utils'

/**
 * state
 */
const state = {
    rx: {
        isSlide: false, // 设置左侧栏切换
        cutting: undefined // 是否要标题 truthy 和 falsy
    },
    cacheState: true, // 缓存状态
    updateLeft: {}, // 更新左侧列表
    updateVisit: {}, // 更新回访
    updatePlate: {}, // 更新二段板块
    leftInfo: {}, // 单个left信息
    userInfo: {}, // 用户信息
    twoToThreeInfo: {}, // 二段传值到三段
    headerTip: {}, // 头部消息
    asideCur: {} // 左侧选中信息
}

/**
 * getters
 */
const getters = {
    rx: state => state.rx,
    cacheState: state => state.cacheState,
    updateLeft: state => state.updateLeft,
    updateVisit: state => state.updateVisit,
    updatePlate: state => state.updatePlate,
    leftInfo: state => state.leftInfo,
    userInfo: state => state.userInfo,
    twoToThreeInfo: state => state.twoToThreeInfo,
    headerTip: state => state.headerTip,
    asideCur: state => state.asideCur
}

/**
 * mutations
 */
const mutations = {
    [types.SET_RX] (state, playload) {
        state.rx = {...state.rx, ...playload}
    },
    [types.SET_CACHE_STATE] (state, playload) {
        state.cacheState = playload
    },
    [types.SET_UPDATE_LEFT] (state, playload = {}) {
        state.updateLeft = {
            date: new Date().getTime(),
            ...playload
        }
    },
    [types.SET_UPDATE_VISIT] (state, playload = {}) {
        state.updateVisit = {
            date: new Date().getTime(),
            ...playload
        }
    },
    [types.SET_UPDATE_PLATE] (state, playload = {}) {
        state.updatePlate = {
            date: new Date().getTime(),
            ...playload
        }
    },
    [types.SET_LEFT_INFO] (state, playload) {
        state.leftInfo = playload
    },
    [types.SET_USER_INFO] (state, playload) {
        if (playload) {
            utils.setLocal('userInfo', playload)
            state.userInfo = playload
        } else {
            state.userInfo = utils.getLocal('userInfo') || {}
        }
    },
    [types.SET_TWO_TO_THREE_INFO] (state, playload) {
        state.twoToThreeInfo = playload
    },
    [types.SET_HEADER_TIP] (state, playload) {
        state.headerTip = playload || {}
    },
    [types.SET_ASIDE_CUR] (state, playload) {
        state.asideCur = playload || {}
    }
}

/**
 * actions
 */
let actions = {

}

export default {
    state,
    getters,
    mutations,
    actions
}
