import Request from '@rx/config/api-config'
/* ***************************---- ------ <<业务图片>>相关信息 ------ ---- ****************************/
/**
 * 创建: lianHaiwei
 * 时间: 2018-06-14
 * 参数: {FileType=0&rwdid=22-87186&catalogid=90&filePath=hhhhhhh&cardNo=02802098}
 * 描述: 图片上传 具体图片类型看<<图片常用功能以及信息>>文档
 */
export function saveImagesUpload (params) {
    return Request.http.post('/api/DWorksDetail/insertWorksDetail', params, 2)
}

/**
 * 创建: lianHaiwei
 * 时间: 2018-06-14
 * 参数: {rwdid=22-120823,catalogID:90,15}
 * 描述: 获取上传的图 具体图片类型看<<图片常用功能以及信息>>文档
 */
export function getImagesUpload (params) {
    return Request.http.get('/api/DWorksDetail/WorksDetailArray', params, 2)
}

/**
 * 创建: lianHaiwei
 * 时间: 2018-06-14
 * 参数: {id=466749}
 * 描述: 物理删除上传的图 具体图片类型看<<图片常用功能以及信息>>文档
 */
export function deleteImagesUpload (params) {
    return Request.http.post('/api/DWorksDetail/deleteWorksDetail', params, 2)
}

/**
 * 创建: lianHaiwei
 * 时间: 2018-06-14
 * 参数: {orderNo:22-87186,projectBrief:''}
 * 描述: 更新设计说明
 */
export function updateProjectBrief (params) {
    return Request.http.post('/api/DWorksDetail/updateProjectBrief', params, 2)
}

/**
 * 创建: lianHaiwei
 * 时间: 2018-06-14
 * 参数: {rwdId}
 * 描述: 获取分类图片信息的首张图
 */
export function getClientImagesCount (params) {
    return Request.http.get('/api/DWorksDetail/ClientImagesCount', params, 2)
}
