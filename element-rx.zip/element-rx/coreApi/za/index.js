import Request from '@rx/config/api-config'
/* ***************************---- ------ <<地区>>相关信息 ------ ---- ****************************/
/**
 * 创建: lianhaiwei
 * 时间: 2018-05-16
 * 参数: { null } || { CustomerDiQu: 11,18,22 }
 * 描述: 获取地区列表
 */
export function getRegionList (params) {
    return Request.http.get('/diqu/diquArray', params, 2)
}

/**
 * 创建: lianhaiwei
 * 时间: 2018-08-30
 * 参数: { ct: 1 }
 * 描述: 获取城下所有的地区
 */
export function getCityList (params) {
    return Request.http.get('/diqu/citydiquArray', params, 2)
}

/**
 * 创建: zhaozhe
 * 时间: 2019-02-21
 * 参数: { ct: 0, fg: 0 }
 * 描述: 获取城地区及城地区下地区id 和 地区列表
 */
export function getChengDiquAndDiqu (params) {
    return Request.http.get('/diqu/getChengDiquAndDiqu', params, 2)
}

/**
 * 创建: lianhaiwei
 * 时间: 2018-08-30
 * 参数: { region=11 }
 * 描述: 根据地区获取设计师
 */
export function getDesignerByRegion (params) {
    return Request.http.get('/api/LocalTask/GetDesignerByRegion', params, 5)
}

/* ***************************---- ------ <<登录>>相关信息 ------ ---- ****************************/
/**
 * 创建: lianhaiwei
 * 时间: 2018-05-16
 * 参数: { diquID ：0 }
 * 描述: 飘单
 */
export function getDesignerFloatSignList (params) {
    return Request.http.get('/negotiate/GetDesignerFloatSignList', params, 2)
}

/**
 * 创建: lianhaiwei
 * 时间: 2018-05-16
 * 参数: { message: 加密字符串 }
 * 3: 集团平台, 8: 瑞祥设计
 * 描述: 登录信息解密
 */
export function getUserInfo (params) {
    return Request.http.get('/api/login/getUserInfo', params, 2)
}

/**
 * 创建: lianhaiwei
 * 时间: 2018-05-16
 * 参数: { card: 000000, password:'RXJYfrfrfrfrdcd2ee', type : }
 * 3: 集团平台, 8: 瑞祥设计
 * 描述: 登录信息加密
 */
export function getUserInfoEncrypt (params) {
    return Request.http.get('/api/login/encrypt', params, 2)
}

/* ***************************---- ------ <<房屋>>相关信息 ------ ---- ****************************/
/**
 * 创建: lianhaiwei
 * 时间: 2018-09-12
 * 参数: { rwdId }
 * 描述: 获取量房信息
 */
export function orderInfo (params) {
    return Request.http.get('/order/orderInfo', params, 2, {loading: false})
}

/* ***************************---- ------ <<绩效>>相关信息 ------ ---- ****************************/
/**
 * 创建: lianhaiwei
 * 时间: 2018-09-12
 * 参数: { em_Sponsor 推送人卡号 em_Executor 给谁操作  em_Content 备注 rp_Money 减少的钱 em_theme 科目 rp_Method罚钱永远是2}
 * 描述: 推送7师奖罚
 */
export function LaunchEventAndOver (params) {
    return Request.http.post('/api/EventPlatform/LaunchEventAndOver', params, 4)
}

/**
 * 创建: lianhaiwei
 * 时间: 2019-01-22
 * 参数: campId
 * 描述: 池子数据
 */
export function complexTable (params) {
    return Request.http.get('/command/complexTable', params, 32)
}
