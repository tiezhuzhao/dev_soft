<template>
<aside id="nav" class="j_leftnav nav-fixed" v-if="!rx.cutting">
    <div class="rolechange j_outer" v-if="rx.isSlide && slideBar && slideBar[0] && slideBar[0].name && slideBar.length >= 2">
        <p v-for="(item,index) in slideBar" :style="{width:100 / slideBar.length + '%'}" :class="{'Pacitve':navListIndex == index}" :key="index" @click="navListSwitch(index)">{{item.name}}</p>
    </div>
    <div class="nav-wrapper" v-scrollHeight="10">
        <div v-for="(list,index) in slideBar" :key="index" v-show="navListIndex == index" class="clearfix">
            <ul class="nav-ul clearfix" v-for="(item, inde) in list.list" :key="inde" style="display:block;">
                <!-- 如果是单级 -->
                <template v-if="!item.children">
                    <router-link @click.native="menuListSwitch(item)" v-if="!item.link.startsWith('http')" tag="li" :to="item.link" :class="{active: menuCurInfo.menuFlag === item.menuFlag}">
                        <a href="javascript:void(0);" data-rippleria="" class="rippleria-dark" style="overflow: hidden; display: block;">
                            <div class="rippleria-wrap">
                                <i class="nav-icon" v-html="item.na"></i><strong v-html="item.name"></strong>
                            </div>
                        </a>
                        <hr class="borderCtr0 hide" v-if="item.iframe">
                    </router-link>
                    <li v-else>
                        <a :href="item.link" target="_blank" class="rippleria-dark" style="overflow: hidden; display: block;">
                            <div class="rippleria-wrap">
                                <i class="nav-icon" v-html="item.na"></i><strong v-html="item.name"></strong>
                            </div>
                        </a>
                        <hr class="borderCtr0 hide" v-if="item.iframe">
                    </li>
                </template>
                <!-- 如果有二级 -->
                <template v-else-if="Array.isArray(item.children)">
                    <li class="menu" :class="{'open':downIndex == inde && rx.isSlide, 'active': item.menuFlag.includes(menuCurInfo.menuFlag)}">
                        <a @click.stop.prevent="downIndexSwitch(inde)" href="javascript:void(0);" data-rippleria="" class="rippleria-dark" style="overflow: hidden; display: block;">
                            <div class="rippleria-wrap">
                                <i class="nav-icon" v-html="item.na"></i><strong v-html="item.name"></strong>
                                <i class="icon-down"></i>
                            </div>
                        </a>
                        <ul class="sub-2-nav" style="display:block;" v-show="downIndex == inde && rx.isSlide">
                            <template v-for="(item, ind) of item.children">
                                <router-link @click.native="menuListSwitch(item)" :key="ind" v-if="!item.link.startsWith('http')" tag="li" :to="item.link" :class="{active: menuCurInfo.menuFlag === item.menuFlag}">
                                    <a href="javascript:void(0);" data-rippleria="" class="rippleria-dark" style="overflow: hidden; display: block;">
                                        <div class="rippleria-wrap">
                                            <em class="icon-circle"></em>
                                            <!-- <i class="nav-icon" v-html="item.na"></i> -->
                                            <strong v-html="item.name"></strong>
                                        </div>
                                    </a>
                                    <hr class="borderCtr0 hide" v-if="item.iframe">
                                </router-link>
                                <li v-else :key="ind">
                                    <a :href="item.link" target="_blank" class="rippleria-dark" style="overflow: hidden; display: block;">
                                        <div class="rippleria-wrap">
                                            <em class="icon-circle"></em>
                                            <i class="nav-icon" v-html="item.na"></i><strong v-html="item.name"></strong>
                                        </div>
                                    </a>
                                    <hr class="borderCtr0 hide" v-if="item.iframe">
                                </li>
                            </template>
                        </ul>
                    </li>
                </template>
            </ul>
        </div>
    </div>
</aside>
</template>
<script>
import { mapGetters, mapMutations } from 'vuex'
import utils from '@rx/utils'
export default {
    name: 'rx-aside',
    props: {
        slideBar: {
            type: Array,
            default: () => {
                return []
            }
        },
        menuInit: Object
    },
    data () {
        return {
            navListIndex: 0,
            downIndex: undefined,
            menuCurInfo: {}
        }
    },
    computed: {
        ...mapGetters(['rx'])
    },
    watch: {
        slideBar: {
            handler () {
                this.$nextTick(() => {
                    this.hoverChildren()
                })
            },
            deep: true,
            immediate: true
        }
    },
    created () {
        if (utils.getSession('menuInit')) {
            this.menuListSwitch(utils.getSession('menuInit'))
        } else {
            if (this.menuInit) {
                this.menuListSwitch(this.menuInit)
            } else {
                try {
                    this.menuListSwitch(this.slideBar[0].list[0])
                } catch (error) {
                    this.menuListSwitch({menuFlag: 0})
                }
            }
        }
    },
    methods: {
        ...mapMutations({
            setAsideCur: 'SET_ASIDE_CUR'
        }),
        // 头部切换
        navListSwitch (index) {
            this.navListIndex = index
        },
        // 列表下拉打开关闭切换
        downIndexSwitch (index) {
            if (this.downIndex === index) {
                this.downIndex = undefined
            } else {
                this.downIndex = index
            }
        },
        // 侧栏切换
        menuListSwitch (item) {
            this.menuCurInfo = item
            utils.setSession('menuInit', item)
            this.$emit('menuClickCall', item)
            this.setAsideCur(item)
        },
        // 划过展示children
        hoverChildren () {
            let eles = document.querySelector('#nav').querySelectorAll('.nav-ul')
            Array.from(eles).forEach((item, index) => {
                item.addEventListener('mouseenter', function () {
                    let _children = item.querySelector('.sub-2-nav')
                    if (_children !== null) {
                        let _winh = document.documentElement.clientHeight
                        let _offt = utils.offset(item).top
                        let _subh = _children.offsetHeight
                        let _scro = document.querySelector('#nav .nav-wrapper').scrollTop
                        if (_winh > (_offt - _scro + _subh)) {
                            utils.setCss(_children, 'top', _offt - _scro)
                        } else {
                            utils.setCss(_children, 'top', _winh - _subh)
                        }
                    } else {
                        // console.log('不存在子级')
                    }
                })
            })
        }
    }
}
</script>
