import Index from './Index.vue'

Index.install = Vue => {
    Vue.component(Index.name, Index)
}

export default Index
