<template>
<!-- 使用默认布局模板控制宽度 -->
<div id="app" :class="{
        'cutting-header-slide': rx.cutting || cutting,
        'nav-collapsed-min': !rx.isSlide,
        'app-slide-open': rx.isSlide,
        'app-slide-close': !rx.isSlide
    }">
    <!-- 控制布局的内填充 -->
    <slot></slot>
</div>
</template>
<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
    name: 'rx-app',
    props: {
        cutting: Boolean // cutting 为 true 时 去掉 默认的头部和侧栏的预留边距
    },
    data () {
        return {
            app: false
        }
    },
    created () {
        // 是否显示头部和侧栏
        if (this.$route.query.cutting) {
            this.setRx({
                cutting: this.$route.query.cutting
            })
        }
        // 根据参数自动存储缓存
        if ((this.$route.query.fg && this.$route.query.ct) || this.$route.query.save) {
            this.autoSave()
        } else {
            this.setUserInfo(null)
        }
    },
    methods: {
        ...mapMutations({
            setRx: 'SET_RX',
            setUserInfo: 'SET_USER_INFO'
        }),
        // 根据参数自动存储缓存 参数必须有 (fg && ct) || save
        autoSave () {
            let query = this.$route.query
            let standard = {}
            let standardArray = ['diquId', 'diquName', 'cardNo', 'password', 'appId', 'jueseId', 'jueseName', 'fullName', 'type', 'fg', 'ct', 'ctChilds']
            // - 标准字段处理成 as_
            let outer = {}
            for (let key in query) {
                if (standardArray.includes(key)) {
                    standard[`as_${key}`] = query[key]
                } else {
                    outer[key] = query[key]
                }
            }
            this.setUserInfo({
                ...standard,
                ...outer
            })
        }
    },
    computed: {
        ...mapGetters(['rx'])
    }
}
// ~~~~~~~~~~~~~~~~~~~
// ~~~~~~~ 无奈 ~~~~~~~
// ~~~~~~~~~~~~~~~~~~~
</script>
