import rxSwitch from './switch'
import rxCheckbox from './checkbox'
import rxRadio from './radio'
import threeTitle from './threeTitle'
import rxHeader from './header'
import rxAside from './aside'
import rxMain from './main'
import rxUpload from './upload'
import rxtitleSwiper from './titleSwiper'
import rxViewer from './viewer'
import rxApp from './app'

export default [
    rxSwitch,
    rxCheckbox,
    rxRadio,
    threeTitle,
    rxHeader,
    rxAside,
    rxMain,
    rxUpload,
    rxtitleSwiper,
    rxViewer,
    rxApp
]
