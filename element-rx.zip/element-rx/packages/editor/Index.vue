<template>
    <div class="clearfix">
        <rx-upload v-show="false" id="editor-upload" @success="successUpload" :init="init">
            <div class="fl uiImgUpload uiImgUpload-gblock mr10">
                <a href="javascript:">
                    <span type="file" value="" class="file"></span>
                    <em class="bgIcon file-ico"></em>
                </a>
            </div>
        </rx-upload>
        <quill-editor ref="rxTextEditor" :style="elStyle"
            v-model="model"
            :options="editorOption"
            @blur="onEditorBlur($event)"
            @focus="onEditorFocus($event)"
            @ready="onEditorReady($event)">
        </quill-editor>
    </div>
</template>
<script>
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import { quillEditor } from 'vue-quill-editor'
export default {
    props: ['value', 'init', 'elStyle'],
    components: {
        quillEditor
    },
    data () {
        return {
            editorOption: {
                modules: {
                    toolbar: {
                        container: [
                            ['bold', 'italic', 'underline', 'strike'],
                            [{
                                'header': [1, 2, 3, 4, 5, 6, false]
                            }],
                            // [{ 'header': 1 }, { 'header': 2 }],
                            [{
                                'list': 'ordered'
                            }, {
                                'list': 'bullet'
                            }],
                            // [{ 'script': 'sub' }, { 'script': 'super' }],
                            // [{ 'indent': '-1' }, { 'indent': '+1' }],
                            // [{ 'direction': 'rtl' }],
                            // [{ 'size': ['small', false, 'large', 'huge'] }],
                            [{
                                'color': []
                            }, {
                                'background': []
                            }],
                            // [{ 'font': [] }],
                            [{
                                'align': []
                            }],
                            // ['clean'],
                            ['link', 'image']
                        ],
                        handlers: {
                            'image': function (value) {
                                if (value) {
                                    // 上传事件点击
                                    document.querySelector('#editor-upload input').click()
                                } else {
                                    this.quill.format('image', false)
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    created () {

    },
    computed: {
        model: {
            get () {
                return this.value
            },
            set (val) {
                this.$emit('input', val)
            }
        }
    },
    methods: {
        // 图片上传之后的回调
        successUpload (data) {
            // 获取富文本组件实例
            let quill = this.$refs.rxTextEditor.quill
            // 获取光标所在位置
            let length = quill.getSelection().index
            // 插入图片  res.info为服务器返回的图片地址
            quill.insertEmbed(length, 'image', data.src)
            // 调整光标到最后
            quill.setSelection(length + 1)
        },
        onEditorBlur (editor) {
            // console.log('editor blur!', editor)
        },
        onEditorFocus (editor) {
            // console.log('editor focus!', editor)
        },
        onEditorReady (editor) {
            // console.log('editor ready!', editor)
        }
    }
}
</script>
