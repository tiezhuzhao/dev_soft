<template>
    <span class="checkedContent" :data-label="label">
        <i class="disabled" v-if="disabled"></i>
        <span class="icon dui" :class="{'active' : acquiescence == 1}" @click.stop="clickYue"></span>
        <span class="icon cuo" :class="{'active' : acquiescence == 0}" @click.stop="clickNo"></span>
    </span>
</template>
<script>
export default {
    name: 'rx-switch',
    props: ['disabled', 'value', 'label'],
    data () {
        return {
            acquiescence: 0,
            name: {}
        }
    },
    created () {

    },
    methods: {
        clickYue () {
            if (this.acquiescence === 1) {
                this.acquiescence = -1
            } else {
                this.acquiescence = 1
            }
            this.bus()
        },
        clickNo () {
            if (this.acquiescence === 0) {
                this.acquiescence = -1
            } else {
                this.acquiescence = 0
            }
            this.bus()
        },
        bus () {
            this.$emit('input', this.acquiescence)
        }
    },
    watch: {
        value: {
            handler () {
                this.acquiescence = this.value
            },
            deep: true,
            immediate: true
        }
    }
}
</script>
