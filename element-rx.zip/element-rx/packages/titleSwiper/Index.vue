<template>
<div class="clearfix">
    <div class="fl tc-center-tabBox" id="rx-tc-center-tabBox">
        <div class="transiotion" :style="{'width': swWidth + 'px', 'margin-left': -(oneWidth * leftIndex) + 'px'}">
            <slot></slot>
        </div>
    </div>
    <div class="fl tc-center-tabBtnDiv">
        <a href="javascript:;" class="tc-center-btn tc-center-prev" @click="prev()"><i></i>
        </a>
        <a href="javascript:;" class="tc-center-btn tc-center-next" @click="next()"><i></i></a>
    </div>
</div>
</template>
<script>
export default {
    name: 'rx-center-title-swiper',
    props: ['data'],
    data () {
        return {
            leftIndex: 0, // 当前点击的累计
            swWidth: 0, // 全部的宽
            swLength: 0, // li 个数
            oneWidth: 0, // 一个的宽
            showLength: 0 // 最多可以显示几个
        }
    },
    mounted () {
        this.computedItem()
    },
    methods: {
        computedItem () {
            this.$nextTick(() => {
                // 获取元素信息
                let listWrap = document.querySelector('#rx-tc-center-tabBox')
                let lists = listWrap.querySelectorAll('#rx-tc-center-tabBox li')
                let listsW = listWrap.offsetWidth

                // 获取宽度
                this.swLength = Array.from(lists).length
                Array.from(lists).forEach((item) => {
                    this.swWidth = this.swWidth + item.offsetWidth
                    if (this.swWidth <= listsW) {
                        this.showLength = this.showLength + 1
                    }
                })
                this.oneWidth = this.swWidth / this.swLength
                // 绑定点击事件
                lists.forEach((item, index) => {
                    item.addEventListener('click', () => {
                        if (index - this.leftIndex >= Math.ceil(this.showLength / 3 * 2)) {
                            this.next()
                        } else if (index - this.leftIndex < Math.ceil(this.showLength / 3)) {
                            this.prev()
                        }
                    })
                })
            })
        },
        // 点击上一个
        prev () {
            if (this.leftIndex !== 0) {
                this.leftIndex = this.leftIndex - 1
            }
        },
        // 点击下一个
        next () {
            if (this.leftIndex < this.swLength - this.showLength) {
                this.leftIndex = this.leftIndex + 1
            }
        }
    },
    watch: {
        data () {
            // 重新初始化
            this.leftIndex = this.swWidth = this.swLength = this.oneWidth = this.showLength = 0
            this.computedItem()
        }
    }
}
</script>
