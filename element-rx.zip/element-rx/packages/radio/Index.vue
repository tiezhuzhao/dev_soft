<template>
    <label
        class="checkedContent rx-radio"
        :class="{
            'disabled': disabled
        }"
        :data-label="label">
        <span
            class="icon dui"
            :class="{
                'active' : model == label
            }">
        </span>
        <input class="hide"
            type="radio"
            :disabled="disabled"
            v-model="model"
            :value="label"/>
    </label>
</template>
<script>
export default {
    name: 'rx-radio',
    props: ['value', 'disabled', 'label'],
    data () {
        return {

        }
    },
    created () {

    },
    computed: {
        model: {
            get () {
                return this.value
            },
            set (val) {
                this.$emit('input', val)
            }
        }
    },
    methods: {

    }
}
</script>
