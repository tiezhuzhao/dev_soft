<template>
    <header v-if="!rx.cutting" id="main_header" class="header-fixed j_outerHeight">
        <h1 id="logo" :style="{'width': rx.isSlide ? '180px' : '50px'}">
            <a href="javascript:;">
                <i></i>
                <span>{{header.title}}</span>
            </a>
        </h1>
        <div id="topnav" :style="{'margin-left': rx.isSlide ? '180px' : '50px'}">
            <!-- 切换 -->
            <ul class="fl">
                <li @click="switchSlide()">
                    <a href="javascript:;" data-rippleria class="setup_nav setupbtn rippleria-dark">
                        <i></i>
                    </a>
                </li>
            </ul>
             <!-- 票单 主案用的地方太多暂时不动 -->
            <!-- <header-coupon ></header-coupon> -->
            <!-- 信息 -->
            <div class="user-div relative fr" @click="headerListSwitch({name: '个人',flag: -1,count: 0,icon: ''})">
                <a href="javascript:;" style="min-width:240px;">
                    <span class='userImg' v-if="userInfo.touxiang">
                        <img :src="userInfo.touxiang" alt="user">
                    </span>
                    <i v-else></i>
                    <span class="mr5" v-if="userInfo.as_fg == 1">城</span>
                    <span class="mr5" v-if="userInfo.as_fg == 1">·</span>
                    <span class="mr5">{{userInfo.as_diquName}}</span>
                    <span class="mr5">·</span>
                    <span class="mr5">{{userInfo.as_jueseName}}</span>
                    <span>-</span>
                    <span class="mr5">{{userInfo.as_fullName}}</span>
                    <span>-</span>
                    <span class="ml5">{{userInfo.as_cardNo}}</span>
                </a>
                <span class="boderBGR" v-if="headerCurInfo.name === '个人'"></span>
                <span class="signGR" v-if="headerCurInfo.name === '个人'"></span>
            </div>
            <!-- 自定义按钮 -->
            <div class="cus-div fr flex">
                <slot></slot>
            </div>
            <!-- 消息按钮 -->
            <div class="cus-div fr flex information">
                <div class="relative tipsBox" v-for="(item, index) in header.list" :key="index" @click="headerListSwitch(item)">
                    <div class="icon fl mr5">
                        <img :src="item.icon" alt="">
                    </div>
                    <span class="fl lh26 relative">
                        {{ item.name }}
                        <span class="tips tx-center" v-if="item.count !== null && item.count !== undefined && item.count !== ''">{{ item.count }}</span>
                    </span>
                    <span class="boderB" v-if="headerCurInfo.name === item.name"></span>
                    <span class="sign" v-if="headerCurInfo.name === item.name"></span>
                </div>
            </div>
        </div>
    </header>
</template>
<script>
import { mapMutations, mapGetters } from 'vuex'
import headerCoupon from './header_coupon.vue'
export default {
    components: {
        headerCoupon
    },
    name: 'rx-header',
    props: {
        header: {
            type: Object,
            default: () => {}
        },
        headerInit: Object
    },
    data () {
        return {
            headerCurInfo: {},
            news: 0
        }
    },
    created () {
    // console.log(this.$ELEMENTRX)
    },
    methods: {
        ...mapMutations({
            setRx: 'SET_RX',
            setHeaderTip: 'SET_HEADER_TIP'
        }),
        switchSlide () {
            this.setRx({
                isSlide: !this.rx.isSlide
            })
        },
        // 侧栏切换
        headerListSwitch (item) {
            this.setHeaderTip(item)
            this.headerCurInfo = item
            // this.$emit('headerClickCall', item)
        }
    },
    computed: {
        ...mapGetters(['rx', 'userInfo', 'headerTip'])
    },
    watch: {
        headerTip () {
            this.headerCurInfo = this.headerTip
            if (this.headerTip.news) {
                this.header.list[4].count = this.headerTip.news
                this.header.list.reverse().reverse()
            }
        }
    }
}
</script>
