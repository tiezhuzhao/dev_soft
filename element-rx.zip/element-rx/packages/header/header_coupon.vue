<template>
    <div id="couponScrollWrap">
        <div class="couponScroll-inner" @click="showDetail()">
            <dl class="clearfix" id="couponScroll">
                <!-- <dd class="pointer"  v-for="(items,index) in couponScrollData" :key="index">
                <span>【{{items.DiquName}}分公司】恭喜设计师</span>
                <span class="fontWeight">{{items.ci_DesignerName}}</span>
                <span v-if="items.OrderType == 1">成功签署设计单</span>
                <span v-if="items.OrderType == 2">成功签署施工单</span>
                <span v-if="items.OrderType == 1 && items.SignAmount >=20000">{{items.SignAmount | signAmount}}万!!</span>
                <span v-if="items.OrderType == 2 && items.SignAmount >=200000">{{items.SignAmount | signAmount}}万!!</span>
                </dd> -->
                <dd class="pointer">
                    <span><span style="font-weight: 900;">通知</span>:7月1日新接项目请在新报价系统中制作:详情查看</span>[<span class="cRed">工具</span>][<span class="cRed">课件</span>][<span class="cRed">报价说明</span>]
                </dd>
            </dl>
        </div>
        <div class="couponScroll-table pa5" v-show="detail">
            <span class="Popover-arrow Popover-arrow--bottom" style="left: 181px; top: 0px;"></span>
            <div class="thinScroll" style="height:350px;overflow-y: auto;">
                <table class="uiTable uiTableLeft uiTable-striped uiTable-hover">
                    <tbody>
                        <!-- <tr v-for="(items,index) in couponScrollData" :key="index">
                        <td>
                            <span>【{{items.DiquName}}分公司】恭喜设计师</span>
                            <span class="fontWeight">{{items.ci_DesignerName}}</span>
                            <span v-if="items.OrderType == 1">成功签署设计单</span>
                            <span v-if="items.OrderType == 2">成功签署施工单</span>
                            <span v-if="items.OrderType == 1 && items.SignAmount >=20000">{{items.SignAmount | signAmount}}万!!</span>
                            <span v-if="items.OrderType == 2 && items.SignAmount >=200000">{{items.SignAmount | signAmount}}万!!</span>
                        </td>
                    </tr> -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { getDesignerFloatSignList } from '@rx/coreApi/za'
export default {
    data () {
        return {
            couponScrollData: [],
            stepNum: 0,
            detail: false
        }
    },
    created () {
        if (!this.rx.cutting) {
            this.getDesignerFloatSignList()
        }
        this.$nextTick(() => {
            $(document).on('click', e => {
                var _con = $('#couponScrollWrap')
                if (!_con.is(e.target) && _con.has(e.target).length === 0) {
                    this.detail = false
                }
            })
        })
    },
    methods: {
    // 获取票单数据
        getDesignerFloatSignList () {
            getDesignerFloatSignList({
                diquId: 0
            })
                .then(res => {
                    this.couponScrollData = res.data.Body
                    this.computedWidth()
                })
                .catch(err => {
                    console.log(err)
                })
        },
        // 显示详情
        showDetail () {
            this.detail = !this.detail
        },
        // 计算高度
        computedWidth () {
            window.clearInterval(window.scrollTime)
            window.scrollTime = window.setInterval(this.scroll, 2000)
        }
        // 飘单函数
        // scroll () {
        //     if (this.stepNum > this.couponScrollData.length) {
        //         window.clearInterval(window.scrollTime)
        //     } else {
        //         this.stepNum += 1
        //         $('.couponScroll-inner').animate({ scrollTop: this.stepNum * 40 }, 500)
        //     }
        // }
    },
    filters: {
        signAmount (items) {
            return (items / 10000).toFixed(1)
        }
    },
    computed: {
        ...mapGetters(['rx', 'userInfo'])
    }
}
</script>
<style lang="scss" scoped>
#couponScrollWrap {
  position: relative;
  float: left;
  width: calc(100% - 850px);
  height: 40px;
}
.couponScroll-inner {
  overflow: hidden;
  width: 100%;
  height: 40px;
  line-height: 40px;
}
.couponScroll-table {
  position: absolute;
  width: 100%;
  top: 50px;
  background: #fff;
  box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
}
#couponScroll {
  width: 100%;
  .fontWeight {
    font-weight: bold;
    padding: 0 5px;
  }
}
#couponScroll dd {
  width: 450px;
  float: left;
  display: flex;
  flex-wrap: nowrap;
}
</style>
