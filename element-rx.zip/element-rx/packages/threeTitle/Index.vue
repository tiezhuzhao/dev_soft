<template>
    <div class="clearfix plr10 pb10">
        <h2 class="uiTitle2" v-if="title">
            <router-link v-if="close" tag="i" :to="backRoot" class="rig_close fr"></router-link>
            <i class="uiTitle-icon"></i>
            <span>{{ title.name }}</span>
            <slot></slot>
        </h2>
        <h2 class="uiTitle2" v-else>
            <!-- <i>&nbsp;</i> -->
            <router-link tag="i" :to="backRoot" class="rig_close fr"></router-link>
        </h2>
    </div>
</template>
<script>
export default {
    /**
     * title 标题名
     * close 是否显示 x 号 true || false
     */
    name: 'three-title',
    props: {
        title: Object,
        close: {
            type: Boolean,
            default: () => true
        }
    },
    data () {
        return {
            backRoot: ''
        }
    },
    created () {
        let hash = this.$route.path
        this.backRoot = hash.slice(hash.indexOf('/'), hash.lastIndexOf('/'))
    }
}
</script>
