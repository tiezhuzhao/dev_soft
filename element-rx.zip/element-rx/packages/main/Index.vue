<template>
<main id="main">
    <slot></slot>
</main>
</template>
<script>
export default {
    name: 'rx-main',
    data () {
        return {

        }
    },
    created () {

    }
}
</script>
