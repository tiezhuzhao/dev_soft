<template>
    <canvas ref="qrcode"></canvas>
</template>
<script>
import qrcode from 'qrcode'
export default {
    name: 'rx-qrcode',
    props: ['value', 'options'],
    data () {
        return {

        }
    },
    created () {

    },
    methods: {
        createQrCode () {
            qrcode.toCanvas(
                this.$refs.qrcode,
                JSON.stringify(this.value),
                this.options,
                error => {
                    if (error) throw error
                }
            )
        }
    },
    watch: {
        value: {
            handler () {
                this.$nextTick(() => {
                    this.createQrCode()
                })
            },
            deep: true,
            immediate: true
        }
    }
}
</script>
