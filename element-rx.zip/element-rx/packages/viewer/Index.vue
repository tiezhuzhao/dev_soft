<template>
  <div class="rx-viewer">
    <slot :images="images" :options="options">
    </slot>
  </div>
</template>
<script>
import Viewer from 'viewerjs'
export default {
    name: 'rx-viewer',
    props: {
        images: [String, Array, Object],
        options: {
            type: Object,
            default: () => {}
        }
    },
    data () {
        return {

        }
    },
    methods: {
        createViewer () {
            // 初始 或 销毁
            this.$viewer && this.$viewer.destroy()
            // 整合配置
            let options = {
                ...this.options,
                navbar: false,
                zoomRatio: 0.3,
                url (image) {
                    return image.src.split('?')[0]
                }
            }
            // 初始配置
            this.$viewer = new Viewer(this.$el, options)
            // 自定义触发事件
            this.$el.querySelectorAll('.enlarge_viewer').forEach((item, index) => {
                item.addEventListener('click', (event) => {
                    event.stopPropagation()
                    this.$viewer.show()
                    this.$viewer.view(index)
                }, false)
            })
        }
    },
    watch: {
        images: {
            handler () {
                this.$nextTick(() => {
                    this.createViewer()
                })
            },
            deep: true,
            immediate: true
        }
    },
    destroyed () {
        this.$viewer && this.$viewer.destroy()
    }
}
</script>
