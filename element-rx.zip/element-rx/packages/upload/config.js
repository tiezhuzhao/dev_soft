/**
 * 上传配置 只配置一级目录  二级通用
 */
const upload = {
    // 二级目录配置通用
    secondLevel: {
        1: '/Images', // 图片
        2: '/Zips', // 压缩包
        3: '/VideoAudio', // 音频视频
        4: '/Docs' // 文档文本资料一类
    },
    // 具体部门
    sw: {
        production: '',
        development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
        options: {

        }
    },
    za: {
        production: 'https://oss.rxjy.com/wenes01/getOSSToken',
        development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
        options: {
            1: 'ProjectBusiness', // 业务
            2: 'DesignInstitute', // 设计院
            3: 'ProjectBusiness', // 业务/人事/财务/其他工具类
            4: 'FurnitureWeakCurrent' // 家具弱电
        }
    },
    gc: {
        production: '',
        development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
        options: {

        }
    },
    ds: {
        production: '',
        development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
        options: {

        }
    },
    pt: {
        production: '',
        development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
        options: {

        }
    },
    tz: {
        production: '',
        development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
        options: {

        }
    },
    kg: {
        production: 'https://oss.rxjy.com/holding01/getOSSToken',
        development: 'https://oss.rxjy.com/rxjy-test/getOSSToken',
        options: {
            1: 'Personnel', // 人事
            2: 'Product', // 产品
            3: 'Finance', // 财务
            4: 'Property', // 物业
            5: 'GroupTube' // 团管
        }
    }
}
export default upload
