<template>
    <label class="checkedContent rx-checkbox"
        :class="{
            'disabled': disabled
        }"
        :data-label="label">
        <span
            class="icon dui"
            :class="{
                'active' : isChecked
            }">
        </span>
        <input class="hide"
            type="checkbox"
            :disabled="disabled"
            v-model="model"
            :value="label"/>
    </label>
</template>
<script>
export default {
    name: 'rx-checkbox',
    props: ['value', 'disabled', 'label'],
    data () {
        return {

        }
    },
    created () {
        // console.log(this.value, this.label)
    },
    computed: {
        model: {
            get () {
                return this.value
            },
            set (val) {
                this.$emit('input', val)
            }
        },
        isChecked () {
            if ({}.toString.call(this.model) === '[object Boolean]') {
                return this.model
            } else if (Array.isArray(this.model)) {
                let _model = false
                for (let item of this.model) {
                    if (JSON.stringify(item) === JSON.stringify(this.label)) {
                        _model = true
                    }
                }
                return _model
            } else if (this.model !== null && this.model !== undefined) {
                return this.model === this.label
            }
        }
    },
    methods: {

    }
}
</script>
<style lang="scss">
</style>
