/**
 * api 配置信息
 */
const config = {
    development: {
        // 控股api测试地址
        1: 'http://192.168.1.194:8200', // 31团-java后台
        2: 'http://192.168.1.23:8082', // APPapi
        3: 'http://192.168.1.23:8081', // 产品地址
        4: 'http://192.168.1.194:8200', // 库-认知测试接口
        5: 'http://192.168.1.23:8099', // 7师-控股-招-岗-名片接口
        6: 'http://192.168.1.23:8086', // 回访内容地址 1680
        7: 'http://192.168.1.23:8109', // 财务地址
        8: 'http://192.168.1.94:9292', // 电商接口
        10: 'http://192.168.1.94:9999', // 大院物业
        11: 'http://192.168.1.17:8899', // 大院运维
        12: 'http://192.168.1.23:8091', // 财务登录地址
        13: 'http://192.168.1.49:7001', // 集团商务 api
        14: 'http://192.168.1.107:9084', // 集团商务 api
        15: 'http://192.168.1.107:9085', // 28团招商地址
        16: 'http://192.168.1.17:8091', // 26团司育
        17: 'http://192.168.1.193:1031', // 集团商务 java api
        18: 'http://192.168.1.195:8851', // 8团
        19: 'http://192.168.1.163:8050', // 14团 招
        20: 'http://192.168.1.194:8081', // 8团 主案业务
        21: 'http://192.168.1.73:8036', // 12团
        22: 'http://192.168.1.68:9101', // 14团 二段 主营
        23: 'http://192.168.1.107:9086', // 6师
        24: 'https://swpubapi.rxjy.com', // 23团 城
        25: 'https://platform.wenes.cn', // 19团 渠
        26: 'http://192.168.1.23:8099', // 营平台
        27: 'http://192.168.1.19:8090', // 投资-人事-瑞祥教育
        28: 'http://192.168.1.23:8090', // 控股-app后台
        29: 'https://kgApp.rxjy.com', // 控股-app
        30: 'http://192.168.1.172:13215', // 22团-项目底层
        31: 'http://192.168.1.191:1088', // 订单系统 java
        32: 'http://192.168.1.194:8200', // 弱电财务
        33: 'http://192.168.1.193:1011', // 商务人事
        34: 'https://hr.rxjy.com/hrapi', // 控股人事 老版接口
        35: 'https://tcoa.rxjy.com', // 获取角色
        36: 'http://192.168.1.62:8002' // 投资财务
    },
    production: {
        // 控股api线上地址
        1: 'https://kgrsapi.rxjy.com', // java后台
        2: 'https://piapi.rxjy.com', // APPapi
        3: 'https://papi.rxjy.com', // 团平台接口
        4: 'https://pht.rxjy.com', // 库-认知测试接口
        5: 'https://pp2.rxjy.com', // 7师-控股-招-岗-名片正式接口
        6: 'https://ph.rxjy.com', // 回访内容地址1680
        7: 'https://pcapi.rxjy.com', // 财务地址
        8: 'https://dshtapi.rxjy.com', // 电商正式接口
        10: 'https://pxwy.rxjy.com', // 大院物业
        11: 'https://pyw.rxjy.com', // 大院运维
        12: 'https://pf.rxjy.com', // 财务登录地址
        13: 'https://sjtapi.rxjy.com', // 集团商务 api
        14: 'https://tp.rxjy.com', // 集团商务 api
        15: 'https://join.rxjy.com', // 28团招商地址
        16: 'https://tcoa.rxjy.com', // 26团司育地址
        17: 'https://smemberapi.rxjy.com', // 集团商务 java api
        18: 'https://zhapi.rxjy.com', // 8团
        19: 'https://gclzs.rxjy.com', // 14团 招
        20: 'https://zaapi.rxjy.com', // 8团
        21: 'https://gxmapi.rxjy.com', // 12团
        22: 'https://gapi.rxjy.com', // 14团 二段 主营
        23: 'https://tcp.rxjy.com', // 6师
        24: 'https://swpubapi.rxjy.com', // 23团 城
        25: 'https://platform.wenes.cn', // 19团 渠
        26: 'https://pt.rxjy.com', // 营平台
        27: 'https://tedu.rxjy.com', // 投资-人事-瑞祥教育
        28: 'https://pr.rxjy.com', // 控股-app后台
        29: 'https://kgApp.rxjy.com', // 控股-app
        30: 'https://kgdb.rxjy.com', // 22团-项目底层
        31: 'https://kgdj.rxjy.com', // 订单系统 java
        32: 'https://zardcw.rxjy.com', // 弱电财务
        33: 'https://perfinapi.rxjy.com', // 商务人事
        34: 'https://hr.rxjy.com/hrapi', // 控股人事 老版接口
        35: 'https://tcoa.rxjy.com', // 获取角色
        36: 'https://fapi.rxjy.com' // 投资财务
    }
}
export default config
