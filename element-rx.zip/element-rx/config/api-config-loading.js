import { Loading } from 'element-ui'

let needLoadingRequestCount = 0
let loading

function startLoading () {
    // console.log('startLoading =============')
    loading = Loading.service({
        lock: true,
        fullscreen: true,
        text: '正在加载...',
        background: 'rgba(255, 255, 255, 0.3)'
    })
}

function endLoading () {
    // console.log('endLoading==========')
    loading.close()
}

const tryCloseLoading = () => {
    if (needLoadingRequestCount === 0) {
        endLoading()
    }
}

export function showFullScreenLoading () {
    if (needLoadingRequestCount === 0) {
        startLoading()
    }
    needLoadingRequestCount++
}

export function tryHideFullScreenLoading () {
    if (needLoadingRequestCount <= 0) return
    needLoadingRequestCount--
    if (needLoadingRequestCount === 0) {
        // tryCloseLoading()
        setTimeout(() => {
            tryCloseLoading()
        })
    }
}
