/**
 * api 配置信息
 */
const config = {
    development: {

    },
    production: {

    }
}
export default config
