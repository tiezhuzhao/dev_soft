/**
 * api 配置信息
 */
const config = {
    development: {
        // 1: 'http://na.wenes.com', // .net
        2: 'http://192.168.1.194:8081', // 主案-业务
        4: 'http://192.168.1.23:8081', // 控股-平台
        5: 'http://10.10.16.68:8889', // 主案-人事
        6: 'http://192.168.1.195:8851', // 设计院
        7: 'http://192.168.1.50:9877', // 工程-报价预算服务
        8: 'https://back.wenes.cn', // 温特斯-后台
        9: 'http://ams.gc.rx:14322', // 工程-接单管理
        10: 'http://192.168.1.50:8892', // 工程-报价
        11: 'http://api.gc.rx', // 工程-主api
        12: 'http://192.168.1.23:8082', // 控股-对外
        // 13: 'http://api.dcwzg.com:9193', // APP后台
        14: 'http://vip.wenes.cn', // 客户端
        15: 'https://www.wenes.cn', // 温特斯
        // 16: 'http://jt.wenes.cn', // 设计院-订单
        // 17: 'http://jt.sjy.cn', // 设计院-所
        18: 'http://zxc.wenes.com', // 装修查
        19: 'https://api.niujingji.cn:8183', // 商务-APP
        20: 'http://wrrsnew.lm.rx', // 工程-外部人事
        21: 'http://api.lm.rx', // 工程-洽谈
        22: 'http://edu.rx', // 投资-人事教育
        // 23: 'http://192.168.1.230:10055',
        24: 'http://jtrs.glxt.rx', // 投资-人事
        25: 'https://zardqt.rxjy.com', // 弱电-洽谈
        26: 'http://192.168.1.194:9696', // 主案-报价
        27: 'http://wy.p.rx', // 控股-物业
        28: 'http://192.168.1.172:13215', // 控股-db调用
        29: 'http://192.168.1.49:2005', // 商务-外部
        // 30: 'http://sms.tehir.cn', // 设计院短信
        31: 'https://gapiaut.rxjy.com', // 工程-审计
        32: 'https://kgapi.rxjy.com', // 底层
        33: 'https://zabj.rxjy.com', // 主案-报价后台
        34: 'https://zajjggapi.rxjy.com', // 家具/弱电-公用
        35: 'http://192.168.1.194:8301', // 家具-加盟商端
        36: 'http://192.168.1.194:8300', // 家具-平台、业务
        37: 'http://r.p.rx', // 控股-app后台
        38: 'https://tcp.rxjy.com', // 投资-城管理平台
        // 39: 'https://zajjdp.rxjy.com', // 家具-店铺
        // 40: 'http://192.168.1.194:8303', // 家具-店铺
        41: 'http://192.168.1.194:8001', // 弱电-业务平台
        42: 'https://ph.rxjy.com', // 控股-大院人事
        // 43: 'https://zrapi.rxjy.com', // 主案-人事
        44: 'http://192.168.1.194:8307', // 家具-产品库
        45: 'http://192.168.1.194:8017', // 弱电-产品库
        46: 'http://192.168.1.194:8306', // 家具-店铺
        47: 'http://192.168.1.194:8016', // 弱电-加盟商
        48: 'https://khdapi.wenes.cn', // 平台-客户平台
        49: 'https://chat.wenes.cn', // 平台-客户平台聊天
        51: 'https://tp.rxjy.com', // 用于查询该人有多少需验收的订单
        52: 'http://192.168.1.65:9003', // 修改小人事头像
        53: 'http://192.168.1.49:9025', // 新闻消息数
        999: ''
    },
    production: {
        // 1: 'http://na.wenes.com', // .net
        2: 'https://zaapi.rxjy.com', // 主案-业务
        4: 'https://papi.rxjy.com', // 控股-平台
        5: 'https://zrapi.rxjy.com', // 主案-人事
        6: 'https://zhapi.rxjy.com', // 设计院
        7: 'https://gbjysfw.rxjy.com', // 工程-报价预算服务
        8: 'https://back.wenes.cn', // 温特斯-后台
        9: 'https://gams.rxjy.com', // 工程-接单管理
        10: 'https://gbjapi.rxjy.com', // 工程-报价
        11: 'https://gapi.rxjy.com', // 工程-主api
        12: 'https://piapi.rxjy.com', // 控股-对外
        // 13: 'https://piapi.rxjy.com', // APP后台
        14: 'https://gzs.rxjy.com', // 客户端
        15: 'https://www.wenes.cn', // 温特斯
        // 16: 'https://ozhapi.rxjy.com', // 设计院-订单
        // 17: 'http://jt.sjy.cn', // 设计院-所
        18: 'https://zxc.rxjy.com', // 装修查
        19: 'https://sappapi.rxjy.com', // 商务-APP
        20: 'https://gwbrs.rxjy.com', // 工程-外部人事
        21: 'https://gjmapi.rxjy.com', // 工程-洽谈
        22: 'https://tedu.rxjy.com', // 投资-人事教育
        // 23: 'http://192.168.1.230:10055',
        24: 'https://hr.rxjy.com', // 投资-人事
        25: 'https://zardqt.rxjy.com', // 弱电-洽谈
        26: 'https://zaapibj.rxjy.com', // 主案-报价
        27: 'https://pwy.rxjy.com', // 控股-物业
        28: 'https://kgdb.rxjy.com', // 控股-db调用
        29: 'https://sidc.rxjy.com', // 商务-外部
        // 30: 'http://sms.tehir.cn', // 设计院短信
        31: 'https://gapiaut.rxjy.com', // 工程-审计
        32: 'https://kgapi.rxjy.com', // 底层
        33: 'https://zabj.rxjy.com', // 主案-报价后台
        34: 'https://zajjggapi.rxjy.com', // 家具/弱电-公用
        35: 'https://zajjjmgl.rxjy.com', // 家具-加盟商端
        36: 'https://zajjpt.rxjy.com', // 家具-平台、业务
        37: 'https://pr.rxjy.com', // 控股-app后台
        38: 'https://tcp.rxjy.com', // 投资-城管理平台
        // 39: 'https://zajjdp.rxjy.com', // 家具-店铺
        // 40: 'https://zajjshop.rxjy.com', // 家具-店铺
        41: 'https://zardyw.rxjy.com', // 弱电-业务平台
        42: 'https://ph.rxjy.com', // 控股-大院人事
        // 43: 'https://zrapi.rxjy.com', // 主案-人事
        44: 'https://zajjcpk.rxjy.com', // 家具-产品库
        45: 'https://zardcpk.rxjy.com', // 弱电-产品库
        46: 'https://zajjdpapi.rxjy.com', // 家具-店铺
        47: 'https://zardzyjmsapi.rxjy.com', // 弱电-业务平台
        48: 'https://khdapi.wenes.cn', // 平台-客户平台
        49: 'https://chat.wenes.cn', // 平台-客户平台聊天
        51: 'https://tp.rxjy.com', // 用于查询该人有多少需验收的订单
        52: 'https://hrapp.rxjy.com', // 修改小人事头像
        53: 'https://tapp.rxjy.com', // 新闻消息数
        999: ''
    }
}
export default config
