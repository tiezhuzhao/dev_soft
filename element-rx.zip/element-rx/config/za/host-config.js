/**
 * 前台域名配置信息
 */
const config = {
    development: {
        1: 'https://www.development.com'
    },
    production: {
        1: 'https://www.production.com'
    }
}
export default config
