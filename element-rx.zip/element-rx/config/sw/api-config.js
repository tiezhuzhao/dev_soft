/**
 * api 配置信息
 */
const config = {
    development: {
        1: 'http://192.168.1.193:1001', // 地方分司测试
        2: 'http://192.168.1.193:1001', // 资源、客源
        3: 'http://192.168.1.193:1011', // 商务人事、财务 java测试
        33: 'http://192.168.1.49:7001', // 商务人事、财务.NET集团API 测试
        4: 'http://192.168.1.193:1031', // 会员
        6: 'http://192.168.1.193:1021', // 公用项目登录地址
        8: 'http://192.168.1.19:8090', // 投资部门培训相关，dns需要修改：192.168.1.28或者192.168.1.29
        9: 'http://192.168.1.23:8082', // 投资部门培训相关，dns需要修改：192.168.1.28或者192.168.1.29 192.168.1.23:8082
        10: 'http://jtrs.glxt.rx/hrapi', // 投资接口域名测试
        11: 'http://192.168.1.172:13215', // 人事底层接口测试
        12: 'http://192.168.1.62:8002', // 财务接口测试
        13: 'http://10.10.13.38:8091', // 获取攻坚数据
        14: 'https://sfssw.rxjy.com', // 地方财务系统地址(内嵌接口)
        99: 'https://pr.rxjy.com/', // 七师app后台
        999: ''
    },
    production: {
        1: 'https://swzy.rxjy.com', // 地方分司正式
        2: 'https://swzy.rxjy.com', // 资源、客源
        3: 'https://perfinapi.rxjy.com', // 商务人事、财务
        33: 'https://sjtapi.rxjy.com', // 商务人事、财务.NET集团API
        4: 'https://smemberapi.rxjy.com', // 会员
        6: 'https://swpubapi.rxjy.com', // 公用项目登录地址
        8: 'https://tedu.rxjy.com/', // 投资部门培训相关，dns需要修改：192.168.1.28或者192.168.1.29
        9: 'https://piapi.rxjy.com/', // 控股 通知接口
        10: 'https://hr.rxjy.com/hrapi', // 投资接口域名正式
        11: 'https://kgdb.rxjy.com', // 人事底层接口正式
        12: 'https://fapi.rxjy.com', // 财务接口正式
        13: 'https://tcoa.rxjy.com', // 获取攻坚数据
        14: 'https://sfssw.rxjy.com', // 地方财务系统地址(内嵌接口)
        99: 'https://pr.rxjy.com/', // 七师app后台
        999: ''
    }
}
export default config
