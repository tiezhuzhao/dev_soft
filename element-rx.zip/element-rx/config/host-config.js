import Vue from 'vue'

// department config
import ds from './ds/host-config'
import gc from './gc/host-config'
import kg from './kg/host-config'
import pt from './pt/host-config'
import sw from './sw/host-config'
import tz from './tz/host-config'
import za from './za/host-config'
let alldepartment = { ds, gc, kg, pt, sw, tz, za }
let department

let hostConfig = function (type) {
    let action = ''
    // 获取部门信息
    if (department === undefined) {
        try {
            let departmenttype = Vue.prototype.$ELEMENTRX.department
            if (!departmenttype) {
                // eslint-disable-next-line
                alert('部门ID未设置，请紧急联系前端解决')
                return false
            }
            department = alldepartment[departmenttype]
        } catch (e) {
            // eslint-disable-next-line
            alert('部门ID未设置，请紧急联系前端解决')
            return false
        }
    }
    // 判断环境变量 获取正确的正式/测试
    if (process.env.NODE_ENV === 'development' || process.env.NODE_TEST === 'development') {
        action = department.development[type]
    } else {
        action = department.production[type]
    }
    return action
}

export default hostConfig
