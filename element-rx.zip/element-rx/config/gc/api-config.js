/**
 * api 配置信息
 */
const config = {
    development: {
        1: 'http://192.168.1.106:8082', // 材料管理
        2: 'http://192.168.1.170:8089', // 材料人事
        3: 'http://192.168.1.170:8050', // 材料招商
        4: 'http://192.168.1.106:6700', // 工程人事
        5: 'http://192.168.1.106:6788', // 工程招聘
        6: 'http://192.168.1.106:6901', // 工程培训
        7: 'http://ams.gc.rx:14322', // 接单管理
        8: 'http://shenji.gc.rx', // 总审
        9: 'http://api.gc.rx:7001', // 审计、接单
        10: 'http://jianli.gc.rx', // 监理
        11: 'http://kefu.gc.rx', // 客服
        12: 'http://jmgl.lm.rx', // 项目平台
        13: 'http://wrxm.lm.rx', // 项目管理
        14: 'http://wrapi.lm.rx', // 发包
        15: 'http://wrrs.lm.rx', // 老外部人事
        16: 'http://mat.gc.rx', // 材料业务
        17: 'http://apimat.gc.rx', // 材料业务API
        18: 'http://c.rxjyzx.com', // 材料商城
        19: 'http://clapi.gc.rx', // 材料平台
        999: ''
    },
    production: {
        1: 'https://gclpt.rxjy.com', // 材料管理
        2: 'https://gclrs.rxjy.com', // 材料人事
        3: 'https://gclzs.rxjy.com', // 材料招商
        4: 'https://gnr.rxjy.com', // 工程人事
        5: 'https://gnrpx.rxjy.com', // 工程招聘
        6: 'https://gnrzp.rxjy.com', // 工程培训
        7: 'http://gams.rxjy.com', // 接单管理
        8: 'http://gaut.rxjy.com', // 总审
        9: 'http://gapiaut.rxjy.com', // 审计、接单
        10: 'http://gjl.rxjy.com', // 监理
        11: 'http://gkf.rxjy.com', // 客服
        12: 'http://gxmpt.rxjy.com', // 项目平台
        13: 'http://gxmgl.rxjy.com', // 项目管理
        14: 'http://gxmapi.rxjy.com', // 发包
        15: 'http://gwbrsold.rxjy.com', // 老外部人事
        16: 'http://gclyw.rxjy.com', // 材料业务
        17: 'http://gclapi.rxjy.com', // 材料业务API
        18: 'http://gclsc.rxjy.com', // 材料商城
        19: 'http://gclpt.rxjy.com', // 材料平台
        999: ''
    }
}
export default config
